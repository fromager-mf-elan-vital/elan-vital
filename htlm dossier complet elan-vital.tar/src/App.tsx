import { useState } from 'react'
import Welcome from './components/Welcome'
import Questionnaire from './components/Questionnaire'
import Results from './components/Results'
import ExerciseLibrary from './components/ExerciseLibrary'
import ExerciseDetail from './components/ExerciseDetail'
import LaunchGuide from './components/LaunchGuide'
import GitHubGuide from './components/GitHubGuide'
import Pricing from './components/Pricing'
import { Exercise, Answer } from './types'

function App() {
  const [currentView, setCurrentView] = useState<'welcome' | 'questionnaire' | 'results' | 'library' | 'exercise' | 'guide' | 'github' | 'pricing'>('welcome')
  const [answers, setAnswers] = useState<Answer[]>([])
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null)
  const [userName, setUserName] = useState('')
  const [isPremium, setIsPremium] = useState(false)

  const handleStartQuestionnaire = (name: string) => {
    setUserName(name)
    setCurrentView('questionnaire')
  }

  const handleQuestionnaireComplete = (answers: Answer[]) => {
    setAnswers(answers)
    setCurrentView('results')
  }

  const handleSelectExercise = (exercise: Exercise) => {
    setSelectedExercise(exercise)
    setCurrentView('exercise')
  }

  const handleBackToResults = () => {
    setCurrentView('results')
    setSelectedExercise(null)
  }

  const handleBackToLibrary = () => {
    setCurrentView('library')
    setSelectedExercise(null)
  }

  const handleSubscribe = () => {
    // Ici tu mettras le lien vers ta page de paiement System.io/Stripe
    // Pour l'instant, on simule l'abonnement
    setIsPremium(true)
    setCurrentView('library')
    alert('🎉 Merci pour ton abonnement ! Tu as maintenant accès à tous les exercices.\n\n(Note : ici tu connecteras ton lien de paiement System.io)')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50">
      {currentView === 'welcome' && (
        <Welcome onStart={handleStartQuestionnaire} onShowGuide={() => setCurrentView('guide')} />
      )}
      
      {currentView === 'questionnaire' && (
        <Questionnaire onComplete={handleQuestionnaireComplete} />
      )}
      
      {currentView === 'results' && (
        <Results 
          answers={answers} 
          userName={userName}
          onSelectExercise={handleSelectExercise}
          onViewAll={() => setCurrentView('library')}
        />
      )}
      
      {currentView === 'library' && (
        <ExerciseLibrary 
          onSelectExercise={handleSelectExercise}
          onBack={handleBackToResults}
          onShowPricing={() => setCurrentView('pricing')}
          isPremium={isPremium}
        />
      )}
      
      {currentView === 'exercise' && selectedExercise && (
        <ExerciseDetail 
          exercise={selectedExercise}
          onBack={handleBackToLibrary}
        />
      )}

      {currentView === 'guide' && (
        <LaunchGuide onBack={() => setCurrentView('welcome')} onShowGitHub={() => setCurrentView('github')} />
      )}

      {currentView === 'github' && (
        <GitHubGuide onBack={() => setCurrentView('guide')} />
      )}

      {currentView === 'pricing' && (
        <Pricing 
          onBack={() => setCurrentView('library')}
          onSubscribe={handleSubscribe}
        />
      )}
    </div>
  )
}

export default App

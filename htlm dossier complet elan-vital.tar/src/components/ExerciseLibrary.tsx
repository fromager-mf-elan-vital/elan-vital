import { useState } from 'react'
import { Exercise, Category } from '../types'
import { exercises, categories } from '../data'

interface ExerciseLibraryProps {
  onSelectExercise: (exercise: Exercise) => void
  onBack: () => void
  onShowPricing: () => void
  isPremium: boolean
}

export default function ExerciseLibrary({ onSelectExercise, onBack, onShowPricing, isPremium }: ExerciseLibraryProps) {
  const [selectedCategory, setSelectedCategory] = useState<Category | 'all'>('all')

  const filteredExercises = selectedCategory === 'all' 
    ? exercises 
    : exercises.filter(e => e.category === selectedCategory)

  const freeCount = exercises.filter(e => !e.premium).length
  const premiumCount = exercises.filter(e => e.premium).length

  return (
    <div className="min-h-screen px-4 py-12">
      {/* Decorative */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 right-20 w-72 h-72 bg-purple-200/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 left-20 w-80 h-80 bg-pink-200/20 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-500 hover:text-purple-600 transition-colors mb-4"
          >
            ← Retour aux résultats
          </button>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">
            Bibliothèque d'exercices 📚
          </h1>
          <p className="text-gray-600 text-lg">
            Explore tous les exercices disponibles. Prends celui qui t'appelle.
          </p>
        </div>

        {/* Premium banner */}
        {!isPremium && (
          <div className="mb-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl p-6 text-white shadow-xl shadow-purple-200/50">
            <div className="flex flex-col md:flex-row items-center gap-4">
              <div className="flex-1">
                <h3 className="text-xl font-bold mb-2">✨ Débloque tous les exercices</h3>
                <p className="text-purple-100 text-sm">
                  Accède à l'intégralité des {premiumCount} exercices premium + les nouveautés chaque mois.
                </p>
              </div>
              <button
                onClick={onShowPricing}
                className="px-6 py-3 bg-white text-purple-600 rounded-xl font-bold hover:scale-105 transition-transform shadow-lg whitespace-nowrap"
              >
                Voir les offres →
              </button>
            </div>
          </div>
        )}

        {isPremium && (
          <div className="mb-8 bg-gradient-to-r from-amber-400 to-orange-400 rounded-2xl p-4 text-white shadow-lg">
            <p className="font-semibold text-center">🌟 Tu as accès à tous les exercices ! Profite bien.</p>
          </div>
        )}

        {/* Stats */}
        <div className="flex gap-4 mb-6">
          <div className="flex-1 bg-green-50 rounded-xl p-3 border border-green-200 text-center">
            <p className="text-2xl font-bold text-green-700">{freeCount}</p>
            <p className="text-xs text-green-600">exercices gratuits</p>
          </div>
          <div className="flex-1 bg-purple-50 rounded-xl p-3 border border-purple-200 text-center">
            <p className="text-2xl font-bold text-purple-700">{premiumCount}</p>
            <p className="text-xs text-purple-600">exercices premium</p>
          </div>
        </div>

        {/* Category filters */}
        <div className="flex flex-wrap gap-3 mb-8">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-5 py-2.5 rounded-xl font-medium transition-all duration-200 ${
              selectedCategory === 'all'
                ? 'bg-purple-500 text-white shadow-lg shadow-purple-300/50'
                : 'bg-white/70 text-gray-600 hover:bg-purple-50 border border-gray-200'
            }`}
          >
            ✨ Tous
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-5 py-2.5 rounded-xl font-medium transition-all duration-200 ${
                selectedCategory === cat.id
                  ? 'bg-purple-500 text-white shadow-lg shadow-purple-300/50'
                  : 'bg-white/70 text-gray-600 hover:bg-purple-50 border border-gray-200'
              }`}
            >
              {cat.emoji} {cat.title}
            </button>
          ))}
        </div>

        {/* Exercises grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredExercises.map((exercise) => {
            const cat = categories.find(c => c.id === exercise.category)
            const isLocked = exercise.premium && !isPremium
            return (
              <button
                key={exercise.id}
                onClick={() => isLocked ? onShowPricing() : onSelectExercise(exercise)}
                className={`group text-left bg-white/70 backdrop-blur-sm rounded-2xl p-6 shadow-md border border-white/80 transition-all duration-300 ${
                  isLocked 
                    ? 'hover:shadow-lg hover:border-purple-200 opacity-90' 
                    : 'hover:shadow-xl hover:border-purple-200 hover:scale-[1.02]'
                }`}
              >
                <div className="flex items-start justify-between mb-4">
                  <span className="text-4xl group-hover:scale-110 transition-transform">{exercise.emoji}</span>
                  <div className="flex flex-col items-end gap-1">
                    <span className={`text-xs px-2 py-1 rounded-full bg-gradient-to-r ${cat?.color} text-white font-medium`}>
                      {cat?.emoji} {cat?.title}
                    </span>
                    {exercise.premium && (
                      <span className="text-xs px-2 py-0.5 bg-gradient-to-r from-amber-400 to-orange-400 text-white rounded-full font-bold">
                        ⭐ PREMIUM
                      </span>
                    )}
                  </div>
                </div>
                <h3 className="font-bold text-gray-800 text-lg mb-2 group-hover:text-purple-700 transition-colors">
                  {exercise.title}
                </h3>
                <p className="text-gray-500 text-sm mb-4 line-clamp-2">
                  {exercise.description}
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded-full">
                      ⏱️ {exercise.duration}
                    </span>
                    <span className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded-full">
                      📊 {exercise.difficulty}
                    </span>
                  </div>
                  {isLocked && (
                    <span className="text-lg">🔒</span>
                  )}
                </div>
                {isLocked && (
                  <div className="mt-3 text-center">
                    <span className="text-xs text-purple-600 font-medium">Débloquer avec Premium →</span>
                  </div>
                )}
                {!isLocked && (
                  <div className="mt-4 flex items-center gap-2 text-purple-500 text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                    Commencer <span>→</span>
                  </div>
                )}
              </button>
            )
          })}
        </div>

        {/* Bottom message */}
        <div className="mt-12 text-center">
          <p className="text-gray-500 text-sm">
            💜 Chaque exercice est un pas vers toi-même. Vas-y à ton rythme.
          </p>
        </div>
      </div>
    </div>
  )
}

import { useMemo } from 'react'
import { Answer, Exercise, Category } from '../types'
import { exercises, categories } from '../data'

interface ResultsProps {
  answers: Answer[]
  userName: string
  onSelectExercise: (exercise: Exercise) => void
  onViewAll: () => void
}

function getRecommendedCategories(answers: Answer[]): Category[] {
  const scores: Record<Category, number> = {
    meditation: 0,
    ancrage: 0,
    'art-therapie': 0,
    emotionnel: 0
  }

  answers.forEach(answer => {
    const val = answer.value
    const values = Array.isArray(val) ? val : [val]

    values.forEach(v => {
      switch (v) {
        case 'vide':
        case 'perdu':
          scores.ancrage += 3
          scores.meditation += 2
          break
        case 'anxieux':
          scores.meditation += 3
          scores.ancrage += 2
          break
        case 'triste':
          scores.emotionnel += 3
          scores['art-therapie'] += 2
          break
        case 'colere':
          scores['art-therapie'] += 3
          scores.emotionnel += 2
          break
        case 'fatigue':
          scores.meditation += 2
          scores.ancrage += 2
          break
        case 'calme':
          scores.meditation += 3
          break
        case 'stabilite':
          scores.ancrage += 3
          break
        case 'expression':
          scores['art-therapie'] += 3
          break
        case 'comprehension':
          scores.emotionnel += 3
          break
        case 'connexion':
          scores.ancrage += 2
          scores.emotionnel += 2
          break
        case 'energie':
          scores.ancrage += 2
          scores['art-therapie'] += 1
          break
        case 'respirer':
          scores.meditation += 3
          break
        case 'bouger':
          scores.ancrage += 3
          break
        case 'creer':
          scores['art-therapie'] += 3
          break
        case 'ecrire':
          scores['art-therapie'] += 2
          scores.emotionnel += 2
          break
        case 'ecouter':
          scores.emotionnel += 3
          break
        case 'nature':
          scores.ancrage += 3
          break
        case 'apaiser':
          scores.meditation += 3
          break
        case 'retrouver':
          scores.emotionnel += 2
          scores.ancrage += 2
          break
        case 'lacher':
          scores.meditation += 3
          break
        case 'force':
          scores.ancrage += 3
          break
        case 'douceur':
          scores.emotionnel += 3
          scores.meditation += 1
          break
        case 'present':
          scores.ancrage += 2
          scores.meditation += 2
          break
      }
    })
  })

  return (Object.entries(scores) as [Category, number][])
    .sort((a, b) => b[1] - a[1])
    .map(([cat]) => cat)
}

export default function Results({ answers, userName, onSelectExercise, onViewAll }: ResultsProps) {
  const recommendedCategories = useMemo(() => getRecommendedCategories(answers), [answers])
  
  const topCategories = recommendedCategories.slice(0, 2)
  
  const recommendedExercises = useMemo(() => {
    const recs: Exercise[] = []
    topCategories.forEach(cat => {
      const catExercises = exercises.filter(e => e.category === cat)
      if (catExercises.length > 0) {
        recs.push(catExercises[0])
      }
    })
    return recs
  }, [topCategories])

  const displayName = userName ? userName : 'toi'
  const topCatInfo = categories.find(c => c.id === topCategories[0])

  return (
    <div className="min-h-screen px-4 py-12">
      {/* Decorative */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 w-72 h-72 bg-purple-200/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-pink-200/20 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-purple-200 to-pink-200 shadow-xl shadow-purple-200/50 mb-6">
            <span className="text-4xl">✨</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-3">
            Merci d'avoir partagé, {displayName} ✨
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Voici les exercices qui correspondent le mieux à ton état d'esprit actuel. 
            Choisis ce qui résonne en toi, sans pression.
          </p>
        </div>

        {/* Primary recommendation */}
        {topCatInfo && (
          <div className="bg-white/70 backdrop-blur-sm rounded-3xl p-8 shadow-xl shadow-purple-100/30 border border-white/80 mb-8">
            <div className="flex items-center gap-4 mb-4">
              <span className="text-4xl">{topCatInfo.emoji}</span>
              <div>
                <h2 className="text-2xl font-bold text-gray-800">{topCatInfo.title}</h2>
                <p className="text-purple-600 font-medium">Recommandation principale</p>
              </div>
            </div>
            <p className="text-gray-600 text-lg mb-6">{topCatInfo.description}</p>
            
            {recommendedExercises.length > 0 && (
              <div className="space-y-3">
                {recommendedExercises.map((exercise) => (
                  <button
                    key={exercise.id}
                    onClick={() => onSelectExercise(exercise)}
                    className="w-full text-left p-5 rounded-2xl bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200/50 hover:shadow-lg hover:scale-[1.01] transition-all duration-300"
                  >
                    <div className="flex items-center gap-4">
                      <span className="text-3xl">{exercise.emoji}</span>
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-800 text-lg">{exercise.title}</h3>
                        <p className="text-gray-500 text-sm">{exercise.description}</p>
                        <div className="flex items-center gap-3 mt-2">
                          <span className="text-xs px-2 py-1 bg-purple-100 text-purple-700 rounded-full">⏱️ {exercise.duration}</span>
                          <span className="text-xs px-2 py-1 bg-green-100 text-green-700 rounded-full">📊 {exercise.difficulty}</span>
                        </div>
                      </div>
                      <span className="text-purple-400 text-xl">→</span>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* All categories */}
        <div className="mb-8">
          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
            <span>🌈</span> Explore toutes les approches
          </h3>
          <div className="grid md:grid-cols-2 gap-4">
            {categories.map((cat) => {
              const catExercises = exercises.filter(e => e.category === cat.id)
              return (
                <button
                  key={cat.id}
                  onClick={onViewAll}
                  className={`text-left p-6 rounded-2xl border-2 transition-all duration-300 hover:shadow-lg hover:scale-[1.02] ${cat.bgColor}`}
                >
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-2xl">{cat.emoji}</span>
                    <h4 className="font-bold text-gray-800">{cat.title}</h4>
                  </div>
                  <p className="text-gray-600 text-sm mb-3">{cat.description}</p>
                  <span className="text-xs text-gray-500">{catExercises.length} exercices disponibles</span>
                </button>
              )
            })}
          </div>
        </div>

        {/* Message bienveillant */}
        <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl p-6 border border-amber-200/50 text-center">
          <p className="text-amber-800">
            🌸 Rappelle-toi : chaque petit pas compte. Tu n'as pas besoin de tout faire d'un coup. 
            Choisis un exercice, fais-le quand tu te sens inspiré·e. Et surtout, amuse-toi !
          </p>
        </div>
      </div>
    </div>
  )
}

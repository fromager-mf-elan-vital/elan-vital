interface PricingProps {
  onBack: () => void
  onSubscribe: () => void
}

export default function Pricing({ onBack, onSubscribe }: PricingProps) {
  return (
    <div className="min-h-screen px-4 py-12">
      {/* Decorative */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 w-72 h-72 bg-purple-200/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-80 h-80 bg-pink-200/20 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 max-w-4xl mx-auto">
        {/* Back button */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-500 hover:text-purple-600 transition-colors mb-6"
        >
          ← Retour
        </button>

        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-amber-200 to-orange-200 shadow-xl shadow-amber-200/50 mb-6">
            <span className="text-4xl">⭐</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-3">
            Passe au niveau supérieur
          </h1>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Débloque tous les exercices premium et accompagne-toi chaque jour dans ton développement personnel.
          </p>
        </div>

        {/* Pricing cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-10">
          {/* Free plan */}
          <div className="bg-white/70 backdrop-blur-sm rounded-3xl p-8 border-2 border-gray-200">
            <div className="text-center mb-6">
              <h3 className="text-xl font-bold text-gray-800 mb-1">Gratuit</h3>
              <p className="text-gray-500 text-sm">Pour découvrir</p>
              <div className="mt-4">
                <span className="text-4xl font-bold text-gray-800">0€</span>
                <span className="text-gray-500">/pour toujours</span>
              </div>
            </div>
            <ul className="space-y-3 mb-8">
              <li className="flex items-center gap-3 text-gray-700">
                <span className="text-green-500">✓</span>
                <span>8 exercices de base</span>
              </li>
              <li className="flex items-center gap-3 text-gray-700">
                <span className="text-green-500">✓</span>
                <span>Questionnaire personnalisé</span>
              </li>
              <li className="flex items-center gap-3 text-gray-700">
                <span className="text-green-500">✓</span>
                <span>Recommandations sur mesure</span>
              </li>
              <li className="flex items-center gap-3 text-gray-400">
                <span>✗</span>
                <span>Exercices premium</span>
              </li>
              <li className="flex items-center gap-3 text-gray-400">
                <span>✗</span>
                <span>Nouveaux exercices mensuels</span>
              </li>
              <li className="flex items-center gap-3 text-gray-400">
                <span>✗</span>
                <span>Formations vidéo</span>
              </li>
            </ul>
            <button
              onClick={onBack}
              className="w-full py-3 border-2 border-gray-300 text-gray-600 rounded-xl font-semibold hover:bg-gray-50 transition-colors"
            >
              Plan actuel
            </button>
          </div>

          {/* Premium plan */}
          <div className="relative bg-gradient-to-br from-purple-500 to-pink-500 rounded-3xl p-8 text-white shadow-2xl shadow-purple-300/50">
            <div className="absolute -top-3 right-6 bg-amber-400 text-amber-900 px-4 py-1 rounded-full text-xs font-bold">
              ⭐ RECOMMANDÉ
            </div>
            <div className="text-center mb-6">
              <h3 className="text-xl font-bold mb-1">Premium</h3>
              <p className="text-purple-100 text-sm">Pour aller plus loin</p>
              <div className="mt-4">
                <span className="text-4xl font-bold">9,90€</span>
                <span className="text-purple-200">/mois</span>
              </div>
              <p className="text-purple-200 text-xs mt-2">ou 97€/an (2 mois offerts)</p>
            </div>
            <ul className="space-y-3 mb-8">
              <li className="flex items-center gap-3">
                <span className="text-amber-300">✓</span>
                <span>Tous les exercices (gratuits + premium)</span>
              </li>
              <li className="flex items-center gap-3">
                <span className="text-amber-300">✓</span>
                <span>Nouveaux exercices chaque mois</span>
              </li>
              <li className="flex items-center gap-3">
                <span className="text-amber-300">✓</span>
                <span>Formations vidéo exclusives</span>
              </li>
              <li className="flex items-center gap-3">
                <span className="text-amber-300">✓</span>
                <span>Ateliers créatifs guidés</span>
              </li>
              <li className="flex items-center gap-3">
                <span className="text-amber-300">✓</span>
                <span>Accès communauté privée</span>
              </li>
              <li className="flex items-center gap-3">
                <span className="text-amber-300">✓</span>
                <span>Support prioritaire</span>
              </li>
            </ul>
            <button
              onClick={onSubscribe}
              className="w-full py-4 bg-white text-purple-600 rounded-xl font-bold text-lg hover:scale-105 transition-transform shadow-lg"
            >
              Je passe Premium ✨
            </button>
            <p className="text-center text-purple-200 text-xs mt-3">
              Paiement sécurisé • Annulation à tout moment
            </p>
          </div>
        </div>

        {/* Garanties */}
        <div className="bg-white/70 backdrop-blur-sm rounded-3xl p-8 border border-white/80">
          <h3 className="text-xl font-bold text-gray-800 mb-6 text-center">💜 Nos garanties</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl mb-2">🔒</div>
              <h4 className="font-semibold text-gray-800 mb-1">Paiement sécurisé</h4>
              <p className="text-gray-500 text-sm">Via Stripe, leader mondial de la sécurité</p>
            </div>
            <div className="text-center">
              <div className="text-3xl mb-2">🔄</div>
              <h4 className="font-semibold text-gray-800 mb-1">Sans engagement</h4>
              <p className="text-gray-500 text-sm">Annule quand tu veux, en 1 clic</p>
            </div>
            <div className="text-center">
              <div className="text-3xl mb-2">💯</div>
              <h4 className="font-semibold text-gray-800 mb-1">Satisfait ou remboursé</h4>
              <p className="text-gray-500 text-sm">14 jours pour tester, remboursé si ça ne te convient pas</p>
            </div>
          </div>
        </div>

        {/* FAQ */}
        <div className="mt-10 bg-white/70 backdrop-blur-sm rounded-3xl p-8 border border-white/80">
          <h3 className="text-xl font-bold text-gray-800 mb-6 text-center">❓ Questions fréquentes</h3>
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold text-gray-800 mb-1">Est-ce que je peux annuler à tout moment ?</h4>
              <p className="text-gray-600 text-sm">Oui, absolument. Tu peux annuler ton abonnement en un clic, sans justification.</p>
            </div>
            <div>
              <h4 className="font-semibold text-gray-800 mb-1">Comment se passe le paiement ?</h4>
              <p className="text-gray-600 text-sm">Le paiement est sécurisé par Stripe. Tu seras prélevé·e automatiquement chaque mois, et tu peux annuler à tout moment.</p>
            </div>
            <div>
              <h4 className="font-semibold text-gray-800 mb-1">Est-ce que les exercices gratuits restent accessibles ?</h4>
              <p className="text-gray-600 text-sm">Oui ! Les exercices gratuits restent accessibles même si tu ne prends pas Premium.</p>
            </div>
            <div>
              <h4 className="font-semibold text-gray-800 mb-1">Y a-t-il des nouveautés régulièrement ?</h4>
              <p className="text-gray-600 text-sm">Oui ! De nouveaux exercices et formations sont ajoutés chaque mois pour les membres Premium.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

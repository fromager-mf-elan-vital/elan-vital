import { useState } from 'react'

interface LaunchGuideProps {
  onBack: () => void
  onShowGitHub?: () => void
}

export default function LaunchGuide({ onBack, onShowGitHub }: LaunchGuideProps) {
  const [activeSection, setActiveSection] = useState(0)

  const sections = [
    { title: "Étape 1 : Vercel", icon: "🌐" },
    { title: "Étape 2 : GitHub", icon: "🐙" },
    { title: "Étape 3 : Paiement", icon: "💳" },
    { title: "Étape 4 : Freemium", icon: "⭐" },
    { title: "Étape 5 : Légal", icon: "⚖️" },
    { title: "Étape 6 : Grandir", icon: "🚀" },
  ]

  return (
    <div className="min-h-screen px-4 py-12">
      {/* Decorative */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 w-72 h-72 bg-purple-200/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-80 h-80 bg-pink-200/20 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 max-w-4xl mx-auto">
        {/* Back button */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-500 hover:text-purple-600 transition-colors mb-6"
        >
          ← Retour à l'accueil
        </button>

        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-amber-200 to-orange-200 shadow-xl shadow-amber-200/50 mb-6">
            <span className="text-4xl">📋</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-3">
            Guide pas à pas
          </h1>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Suis chaque étape dans l'ordre. Tu as déjà une entreprise et Stripe, on va aller vite !
          </p>
        </div>

        {/* Navigation sections */}
        <div className="flex flex-wrap gap-2 mb-8 justify-center">
          {sections.map((section, index) => (
            <button
              key={index}
              onClick={() => setActiveSection(index)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${
                activeSection === index
                  ? 'bg-purple-500 text-white shadow-lg shadow-purple-300/50'
                  : 'bg-white/70 text-gray-600 hover:bg-purple-50 border border-gray-200'
              }`}
            >
              {section.icon} {section.title}
            </button>
          ))}
        </div>

        {/* Content sections */}
        <div className="space-y-6">

          {/* ===== SECTION 1 : VERCEL PAS À PAS ===== */}
          {activeSection === 0 && (
            <div className="bg-white/70 backdrop-blur-sm rounded-3xl p-8 shadow-xl shadow-purple-100/30 border border-white/80 animate-fadeIn">
              <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center gap-3">
                <span className="text-3xl">🌐</span>
                Publier sur Vercel (pas à pas)
              </h2>
              <p className="text-gray-600 mb-6">
                Vercel est la plateforme la plus simple pour mettre ton site en ligne. C'est gratuit et ça prend 5 minutes.
              </p>
              
              <div className="space-y-6">
                {/* Étape 1 */}
                <div className="bg-blue-50 rounded-2xl p-6 border border-blue-200">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-sm">1</div>
                    <h3 className="font-bold text-blue-800 text-lg">Créer un compte GitHub</h3>
                  </div>
                  <p className="text-blue-700 mb-3">Vercel a besoin de GitHub pour fonctionner.</p>
                  <ol className="space-y-2 text-blue-700 text-sm">
                    <li>1. Va sur <strong>github.com</strong></li>
                    <li>2. Clique sur "Sign up"</li>
                    <li>3. Entre ton email, choisis un mot de passe et un nom d'utilisateur</li>
                    <li>4. Vérifie ton email</li>
                    <li>5. C'est fait ! Tu as un compte GitHub</li>
                  </ol>
                  <div className="mt-3 bg-blue-100 rounded-lg p-3">
                    <p className="text-blue-800 text-xs">💡 <strong>Important :</strong> Mets ton code en <strong>privé</strong> (repo private) pour protéger ton travail puisque tu veux le monétiser.</p>
                  </div>
                </div>

                {/* Étape 2 */}
                <div className="bg-green-50 rounded-2xl p-6 border border-green-200">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center font-bold text-sm">2</div>
                    <h3 className="font-bold text-green-800 text-lg">Mettre ton code sur GitHub</h3>
                  </div>
                  <p className="text-green-700 mb-3">Tu dois envoyer ton code sur GitHub. Voici comment faire :</p>
                  
                  <div className="bg-white/80 rounded-xl p-4 mb-4">
                    <p className="font-semibold text-green-800 mb-2">Option A : Via le site GitHub (le plus simple)</p>
                    <ol className="space-y-2 text-green-700 text-sm">
                      <li>1. Sur GitHub, clique sur le "+" en haut à droite → "New repository"</li>
                      <li>2. Donne un nom : <code className="bg-green-100 px-1 rounded">elan-vital</code></li>
                      <li>3. Coche <strong>Private</strong> (important !)</li>
                      <li>4. Clique "Create repository"</li>
                      <li>5. Clique "uploading an existing file"</li>
                      <li>6. Glisse tous les fichiers de ton projet dans la zone</li>
                      <li>7. Clique "Commit changes"</li>
                    </ol>
                  </div>

                  <div className="bg-white/80 rounded-xl p-4">
                    <p className="font-semibold text-green-800 mb-2">Option B : Via le terminal (si tu es à l'aise)</p>
                    <div className="bg-gray-900 rounded-lg p-3 text-green-300 text-xs font-mono space-y-1">
                      <p>git init</p>
                      <p>git add .</p>
                      <p>git commit -m "Premier commit"</p>
                      <p>git branch -M main</p>
                      <p>git remote add origin https://github.com/TON-USER/elan-vital.git</p>
                      <p>git push -u origin main</p>
                    </div>
                  </div>
                </div>

                {/* Étape 3 */}
                <div className="bg-purple-50 rounded-2xl p-6 border border-purple-200">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-8 h-8 bg-purple-500 text-white rounded-full flex items-center justify-center font-bold text-sm">3</div>
                    <h3 className="font-bold text-purple-800 text-lg">Créer un compte Vercel</h3>
                  </div>
                  <ol className="space-y-2 text-purple-700 text-sm">
                    <li>1. Va sur <strong>vercel.com</strong></li>
                    <li>2. Clique "Sign Up"</li>
                    <li>3. Choisis "Continue with GitHub" (le plus simple)</li>
                    <li>4. Autorise Vercel à accéder à ton GitHub</li>
                    <li>5. C'est fait !</li>
                  </ol>
                </div>

                {/* Étape 4 */}
                <div className="bg-pink-50 rounded-2xl p-6 border border-pink-200">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-8 h-8 bg-pink-500 text-white rounded-full flex items-center justify-center font-bold text-sm">4</div>
                    <h3 className="font-bold text-pink-800 text-lg">Importer ton projet sur Vercel</h3>
                  </div>
                  <ol className="space-y-2 text-pink-700 text-sm">
                    <li>1. Sur le dashboard Vercel, clique <strong>"Add New..."</strong> → <strong>"Project"</strong></li>
                    <li>2. Tu verras la liste de tes repos GitHub</li>
                    <li>3. Trouve <strong>"elan-vital"</strong> et clique <strong>"Import"</strong></li>
                    <li>4. Vercel détecte automatiquement que c'est un projet Vite/React</li>
                    <li>5. Ne change rien aux settings, clique <strong>"Deploy"</strong></li>
                    <li>6. ⏳ Attends 30 secondes...</li>
                    <li>7. 🎉 <strong>C'EST EN LIGNE !</strong></li>
                  </ol>
                  <div className="mt-3 bg-pink-100 rounded-lg p-3">
                    <p className="text-pink-800 text-xs">💡 Tu obtiens une URL du type : <code>elan-vital.vercel.app</code></p>
                  </div>
                </div>

                {/* Étape 5 */}
                <div className="bg-amber-50 rounded-2xl p-6 border border-amber-200">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-8 h-8 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-sm">5</div>
                    <h3 className="font-bold text-amber-800 text-lg">Mettre à jour ton site (à chaque modification)</h3>
                  </div>
                  <p className="text-amber-700 mb-3">Chaque fois que tu modifies ton code :</p>
                  <ol className="space-y-2 text-amber-700 text-sm">
                    <li>1. Modifie tes fichiers localement</li>
                    <li>2. Envoie les changements sur GitHub (<code className="bg-amber-100 px-1 rounded">git push</code>)</li>
                    <li>3. <strong>Vercel redéploie automatiquement !</strong> En 30 secondes, ton site est mis à jour.</li>
                  </ol>
                  <div className="mt-3 bg-amber-100 rounded-lg p-3">
                    <p className="text-amber-800 text-xs">💡 C'est la magie de Vercel : à chaque push sur GitHub, ton site se met à jour tout seul.</p>
                  </div>
                </div>

                {/* Étape 6 - Nom de domaine */}
                <div className="bg-gray-50 rounded-2xl p-6 border border-gray-200">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-8 h-8 bg-gray-500 text-white rounded-full flex items-center justify-center font-bold text-sm">6</div>
                    <h3 className="font-bold text-gray-800 text-lg">(Optionnel) Ajouter un nom de domaine pro</h3>
                  </div>
                  <p className="text-gray-700 mb-3">Pour avoir <code className="bg-gray-200 px-1 rounded">elanvital.fr</code> au lieu de <code className="bg-gray-200 px-1 rounded">elan-vital.vercel.app</code> :</p>
                  <ol className="space-y-2 text-gray-700 text-sm">
                    <li>1. Achète un domaine chez OVH, Namecheap ou Hostinger (~10€/an)</li>
                    <li>2. Dans Vercel : Settings → Domains → Add</li>
                    <li>3. Entre ton domaine</li>
                    <li>4. Vercel te donne les DNS à configurer chez ton registrar</li>
                    <li>5. Attends 1-24h et c'est en ligne !</li>
                  </ol>
                </div>

                {/* Résumé */}
                <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-6 border border-green-200">
                  <h3 className="font-bold text-green-800 mb-3">✅ Résumé - Ce que tu dois faire MAINTENANT :</h3>
                  <ol className="space-y-2 text-green-700 text-sm font-medium">
                    <li>1. ✅ Créer un compte GitHub (5 min)</li>
                    <li>2. ✅ Uploader ton code sur GitHub en privé (10 min)</li>
                    <li>3. ✅ Créer un compte Vercel avec GitHub (2 min)</li>
                    <li>4. ✅ Importer le projet et cliquer Deploy (1 min)</li>
                    <li>5. ✅ Ton site est en ligne ! 🎉</li>
                  </ol>
                  <p className="text-green-600 text-xs mt-3">Temps total estimé : 20 minutes</p>
                </div>
              </div>
            </div>
          )}

          {/* ===== SECTION 2 : GITHUB ===== */}
          {activeSection === 1 && (
            <div className="bg-white/70 backdrop-blur-sm rounded-3xl p-8 shadow-xl shadow-purple-100/30 border border-white/80 animate-fadeIn">
              <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center gap-3">
                <span className="text-3xl">🐙</span>
                GitHub en détail
              </h2>
              
              <div className="space-y-6">
                <div className="bg-gray-50 rounded-2xl p-6 border border-gray-200">
                  <h3 className="font-bold text-gray-800 mb-3">🤔 C'est quoi GitHub ?</h3>
                  <p className="text-gray-700 mb-3">
                    GitHub est une plateforme qui stocke ton code en ligne. C'est indispensable pour Vercel.
                  </p>
                  <ul className="space-y-2 text-gray-700 text-sm">
                    <li>✅ <strong>Sauvegarde</strong> ton code dans le cloud</li>
                    <li>✅ <strong>Historique</strong> de toutes tes modifications</li>
                    <li>✅ <strong>Nécessaire</strong> pour déployer sur Vercel</li>
                    <li>✅ <strong>Portfolio</strong> pour montrer ton travail</li>
                  </ul>
                </div>

                <div className="bg-green-50 rounded-2xl p-6 border border-green-200">
                  <h3 className="font-bold text-green-800 mb-3">🔒 Public ou Privé ?</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="bg-white/80 rounded-xl p-4">
                      <p className="font-semibold text-green-700 mb-2">🔓 Public</p>
                      <ul className="text-green-700 text-sm space-y-1">
                        <li>• Tout le monde voit ton code</li>
                        <li>• Gratuit</li>
                        <li>• ❌ Pas recommandé pour toi</li>
                      </ul>
                    </div>
                    <div className="bg-white/80 rounded-xl p-4 border-2 border-green-300">
                      <p className="font-semibold text-green-700 mb-2">🔒 Privé ✓</p>
                      <ul className="text-green-700 text-sm space-y-1">
                        <li>• Toi seul vois ton code</li>
                        <li>• Gratuit aussi</li>
                        <li>• ✅ Protège ton business</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-amber-50 rounded-2xl p-4 border border-amber-200">
                  <p className="text-amber-800 text-sm">
                    💡 <strong>Important :</strong> Mets ton repo en <strong>privé</strong>. Le site déployé reste visible par tous, mais le code source (ton business) est protégé.
                  </p>
                </div>

                {onShowGitHub && (
                  <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-6 border border-blue-200 mt-6">
                    <h3 className="font-bold text-blue-800 mb-3">🎯 Besoin d'aide pour créer ton repo GitHub ?</h3>
                    <p className="text-blue-700 text-sm mb-4">
                      J'ai créé un guide visuel étape par étape avec des illustrations pour t'aider à créer ton repo "elan-vital" en privé.
                    </p>
                    <button
                      onClick={onShowGitHub}
                      className="w-full px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl font-semibold shadow-lg shadow-blue-300/50 hover:shadow-xl hover:scale-105 transition-all"
                    >
                      📖 Voir le guide GitHub illustré →
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ===== SECTION 3 : PAIEMENT ===== */}
          {activeSection === 2 && (
            <div className="bg-white/70 backdrop-blur-sm rounded-3xl p-8 shadow-xl shadow-purple-100/30 border border-white/80 animate-fadeIn">
              <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center gap-3">
                <span className="text-3xl">💳</span>
                Connecter ton paiement (System.io + Stripe)
              </h2>
              <p className="text-gray-600 mb-6">
                Tu as déjà une entreprise et Stripe sur System.io. Parfait ! Voici comment connecter le tout.
              </p>
              
              <div className="space-y-6">
                <div className="bg-green-50 rounded-2xl p-6 border border-green-200">
                  <h3 className="font-bold text-green-800 mb-3">✅ Ce que tu as déjà</h3>
                  <ul className="space-y-2 text-green-700 text-sm">
                    <li>✅ Une entreprise (statut juridique)</li>
                    <li>✅ Un compte System.io</li>
                    <li>✅ Stripe connecté à System.io</li>
                    <li>→ Tu peux encaisser de l'argent !</li>
                  </ul>
                </div>

                <div className="bg-blue-50 rounded-2xl p-6 border border-blue-200">
                  <h3 className="font-bold text-blue-800 mb-3">🔗 Option 1 : Lien de paiement System.io (le plus simple)</h3>
                  <p className="text-blue-700 mb-3">System.io te permet de créer des liens de paiement directement.</p>
                  <ol className="space-y-2 text-blue-700 text-sm">
                    <li>1. Connecte-toi à <strong>System.io</strong></li>
                    <li>2. Va dans <strong>"Ventes"</strong> → <strong>"Liens de paiement"</strong></li>
                    <li>3. Crée un nouveau lien : "Abonnement Premium Élan Vital"</li>
                    <li>4. Prix : 9,90€/mois (récurrent)</li>
                    <li>5. Copie le lien généré</li>
                    <li>6. Dans ton app, le bouton "Je passe Premium" redirige vers ce lien</li>
                  </ol>
                  <div className="mt-3 bg-blue-100 rounded-lg p-3">
                    <p className="text-blue-800 text-xs">💡 <strong>Avantage :</strong> System.io gère tout : paiement, abonnement, emails, espace membre. Zéro code supplémentaire !</p>
                  </div>
                </div>

                <div className="bg-purple-50 rounded-2xl p-6 border border-purple-200">
                  <h3 className="font-bold text-purple-800 mb-3">🔗 Option 2 : Page de vente System.io</h3>
                  <p className="text-purple-700 mb-3">Crée une belle page de vente sur System.io.</p>
                  <ol className="space-y-2 text-purple-700 text-sm">
                    <li>1. Dans System.io : <strong>"Pages"</strong> → <strong>"Créer une page"</strong></li>
                    <li>2. Choisis un template de page de vente</li>
                    <li>3. Personnalise avec tes textes, screenshots de l'app</li>
                    <li>4. Ajoute ton offre Premium avec Stripe</li>
                    <li>5. Publie la page</li>
                    <li>6. Dans ton app, le bouton Premium redirige vers cette page</li>
                  </ol>
                  <div className="mt-3 bg-purple-100 rounded-lg p-3">
                    <p className="text-purple-800 text-xs">💡 <strong>Avantage :</strong> Page professionnelle avec tunnel de vente complet. Tu peux aussi l'utiliser pour tes pubs.</p>
                  </div>
                </div>

                <div className="bg-amber-50 rounded-2xl p-6 border border-amber-200">
                  <h3 className="font-bold text-amber-800 mb-3">🔗 Option 3 : Stripe direct (plus avancé)</h3>
                  <p className="text-amber-700 mb-3">Intégrer Stripe directement dans l'app (nécessite du code).</p>
                  <ol className="space-y-2 text-amber-700 text-sm">
                    <li>1. Créer un produit récurrent sur Stripe Dashboard</li>
                    <li>2. Générer un Payment Link Stripe</li>
                    <li>3. Rediriger l'utilisateur vers ce lien</li>
                    <li>4. Gérer le webhook pour débloquer l'accès</li>
                  </ol>
                  <div className="mt-3 bg-amber-100 rounded-lg p-3">
                    <p className="text-amber-800 text-xs">💡 <strong>Conseil :</strong> Commence avec l'Option 1 (lien System.io). C'est le plus rapide et tu n'as pas besoin de coder plus.</p>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-6 border border-green-200">
                  <h3 className="font-bold text-green-800 mb-3">🎯 Ma recommandation pour TOI :</h3>
                  <div className="bg-white/80 rounded-xl p-4">
                    <p className="text-green-800 font-semibold mb-2">Utilise System.io pour tout :</p>
                    <ul className="text-green-700 text-sm space-y-1">
                      <li>✅ Page de vente (tunnel de vente)</li>
                      <li>✅ Lien de paiement (Stripe)</li>
                      <li>✅ Emails automatiques (bienvenue, rappel...)</li>
                      <li>✅ Espace membre (pour accéder aux contenus premium)</li>
                      <li>✅ Affiliation (si tu veux que d'autres vendent pour toi)</li>
                    </ul>
                    <p className="text-green-600 text-xs mt-3">Dans ton app, tu rediriges simplement vers ton lien System.io. Simple, efficace, tout est géré.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ===== SECTION 4 : FREEMIUM ===== */}
          {activeSection === 3 && (
            <div className="bg-white/70 backdrop-blur-sm rounded-3xl p-8 shadow-xl shadow-purple-100/30 border border-white/80 animate-fadeIn">
              <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center gap-3">
                <span className="text-3xl">⭐</span>
                Modèle Freemium : ce qui est en place
              </h2>
              <p className="text-gray-600 mb-6">
                Ton application est déjà configurée avec le modèle freemium. Voici comment ça marche :
              </p>
              
              <div className="space-y-6">
                <div className="bg-green-50 rounded-2xl p-6 border border-green-200">
                  <h3 className="font-bold text-green-800 mb-3">🆓 Exercices GRATUITS (8 exercices)</h3>
                  <p className="text-green-700 mb-3">Accessibles à tous, pour donner envie d'aller plus loin.</p>
                  <div className="grid md:grid-cols-2 gap-2">
                    {[
                      { emoji: '🌬️', name: 'Respiration consciente' },
                      { emoji: '🙏', name: 'Méditation de gratitude' },
                      { emoji: '🌳', name: 'L\'arbre intérieur' },
                      { emoji: '👁️', name: 'Les 5 sens' },
                      { emoji: '🎨', name: 'Le dessin intuitif' },
                      { emoji: '✍️', name: 'L\'écriture intuitive' },
                      { emoji: '📔', name: 'Le journal de gratitude' },
                      { emoji: '✨', name: 'Les affirmations positives' },
                    ].map((ex, i) => (
                      <div key={i} className="flex items-center gap-2 bg-white/80 rounded-lg p-2">
                        <span>{ex.emoji}</span>
                        <span className="text-green-700 text-sm">{ex.name}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-purple-50 rounded-2xl p-6 border border-purple-200">
                  <h3 className="font-bold text-purple-800 mb-3">⭐ Exercices PREMIUM (8 exercices)</h3>
                  <p className="text-purple-700 mb-3">Réservés aux abonnés, pour les motiver à passer Premium.</p>
                  <div className="grid md:grid-cols-2 gap-2">
                    {[
                      { emoji: '🫧', name: 'Scan corporel bienveillant' },
                      { emoji: '🌟', name: 'Visualisation positive' },
                      { emoji: '🚶', name: 'La marche consciente' },
                      { emoji: '🌲', name: 'Bain de nature' },
                      { emoji: '🔮', name: 'Le mandala personnel' },
                      { emoji: '🖼️', name: 'Le tableau de vision' },
                      { emoji: '💌', name: 'La lettre à soi-même' },
                      { emoji: '💎', name: 'Les valeurs personnelles' },
                    ].map((ex, i) => (
                      <div key={i} className="flex items-center gap-2 bg-white/80 rounded-lg p-2">
                        <span>{ex.emoji}</span>
                        <span className="text-purple-700 text-sm">{ex.name}</span>
                        <span className="ml-auto text-xs bg-amber-400 text-white px-1.5 py-0.5 rounded-full">⭐</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-amber-50 rounded-2xl p-6 border border-amber-200">
                  <h3 className="font-bold text-amber-800 mb-3">💰 Tarification recommandée</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="bg-white/80 rounded-xl p-4">
                      <p className="font-bold text-amber-800 text-lg">9,90€/mois</p>
                      <p className="text-amber-700 text-sm">Abonnement mensuel</p>
                      <p className="text-amber-600 text-xs mt-1">Sans engagement, annulable à tout moment</p>
                    </div>
                    <div className="bg-white/80 rounded-xl p-4 border-2 border-amber-300">
                      <p className="font-bold text-amber-800 text-lg">97€/an</p>
                      <p className="text-amber-700 text-sm">Abonnement annuel</p>
                      <p className="text-amber-600 text-xs mt-1">2 mois offerts ! (-18%)</p>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-pink-50 to-rose-50 rounded-2xl p-6 border border-pink-200">
                  <h3 className="font-bold text-pink-800 mb-3">🎯 Stratégie Freemium</h3>
                  <ul className="space-y-2 text-pink-700 text-sm">
                    <li>🎣 <strong>Les exercices gratuits</strong> = l'appât. Ils doivent être excellents pour donner envie.</li>
                    <li>🔒 <strong>Les exercices premium</strong> = la valeur. Plus complets, plus profonds.</li>
                    <li>📧 <strong>Emails</strong> = System.io envoie des emails pour rappeler et convertir.</li>
                    <li>🆕 <strong>Nouveautés</strong> = Ajoute des exercices premium chaque mois pour justifier l'abonnement.</li>
                    <li>🎁 <strong>Bonus</strong> = Formations vidéo, ateliers en direct, communauté privée.</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* ===== SECTION 5 : LÉGAL ===== */}
          {activeSection === 4 && (
            <div className="bg-white/70 backdrop-blur-sm rounded-3xl p-8 shadow-xl shadow-purple-100/30 border border-white/80 animate-fadeIn">
              <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center gap-3">
                <span className="text-3xl">⚖️</span>
                Aspects légaux (simplifiés)
              </h2>
              
              <div className="space-y-6">
                <div className="bg-green-50 rounded-2xl p-6 border border-green-200">
                  <h3 className="font-bold text-green-800 mb-3">✅ Bonne nouvelle !</h3>
                  <p className="text-green-700 mb-3">
                    Ton app est dans le <strong>bien-être et le développement personnel</strong>, pas la santé mentale. C'est beaucoup moins réglementé !
                  </p>
                  <ul className="space-y-2 text-green-700 text-sm">
                    <li>✅ Pas besoin d'avocat pour commencer</li>
                    <li>✅ Pas de réglementation médicale</li>
                    <li>✅ Tu as déjà une entreprise → tu peux facturer</li>
                    <li>✅ Stripe/System.io gèrent la facturation automatiquement</li>
                  </ul>
                </div>

                <div className="bg-blue-50 rounded-2xl p-6 border border-blue-200">
                  <h3 className="font-bold text-blue-800 mb-3">📋 Ce qu'il te faut quand même</h3>
                  <ul className="space-y-2 text-blue-700 text-sm">
                    <li>• <strong>Mentions légales</strong> sur ton site (obligatoire)</li>
                    <li>• <strong>Politique de confidentialité</strong> (si tu collectes des emails)</li>
                    <li>• <strong>CGV</strong> (Conditions Générales de Vente) si tu vends</li>
                    <li>• <strong>Cookie banner</strong> si tu utilises des cookies</li>
                  </ul>
                  <div className="mt-3 bg-blue-100 rounded-lg p-3">
                    <p className="text-blue-800 text-xs">💡 <strong>Astuce :</strong> System.io génère automatiquement des CGV et une politique de confidentialité pour tes pages de vente. Utilise-les comme base !</p>
                  </div>
                </div>

                <div className="bg-purple-50 rounded-2xl p-6 border border-purple-200">
                  <h3 className="font-bold text-purple-800 mb-3">📝 Mentions légales - Ce qu'il faut mettre</h3>
                  <ul className="space-y-2 text-purple-700 text-sm">
                    <li>• Nom de ton entreprise</li>
                    <li>• Forme juridique (SARL, SAS, auto-entrepreneur...)</li>
                    <li>• Adresse du siège social</li>
                    <li>• Numéro SIRET</li>
                    <li>• Email de contact</li>
                    <li>• Numéro de TVA (si applicable)</li>
                    <li>• Hébergeur du site (Vercel)</li>
                  </ul>
                  <div className="mt-3 bg-purple-100 rounded-lg p-3">
                    <p className="text-purple-800 text-xs">💡 <strong>Générateur gratuit :</strong> legalplace.fr ou service-public.fr pour créer tes mentions légales.</p>
                  </div>
                </div>

                <div className="bg-amber-50 rounded-2xl p-4 border border-amber-200">
                  <p className="text-amber-800 text-sm">
                    💡 <strong>Conseil :</strong> Tu as déjà une entreprise, donc tu as déjà tes mentions légales quelque part. Récupère-les et adapte-les pour ton site. Pas besoin de payer un avocat !
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ===== SECTION 6 : GRANDIR ===== */}
          {activeSection === 5 && (
            <div className="bg-white/70 backdrop-blur-sm rounded-3xl p-8 shadow-xl shadow-purple-100/30 border border-white/80 animate-fadeIn">
              <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center gap-3">
                <span className="text-3xl">🚀</span>
                Faire grandir ton projet
              </h2>
              
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-6 border border-purple-200">
                  <h3 className="font-bold text-purple-800 mb-3">📈 Améliorations à ajouter</h3>
                  <ul className="space-y-2 text-purple-700 text-sm">
                    <li>• <strong>Comptes utilisateurs</strong> : sauvegarder la progression</li>
                    <li>• <strong>Formations vidéo</strong> : enregistre-toi en train de guider les exercices</li>
                    <li>• <strong>Audio méditations</strong> : enregistre des guidances vocales</li>
                    <li>• <strong>Notifications</strong> : rappels doux pour pratiquer</li>
                    <li>• <strong>Journal personnel</strong> : espace d'écriture privé</li>
                    <li>• <strong>Ateliers en direct</strong> : sessions Zoom mensuelles</li>
                    <li>• <strong>Communauté</strong> : forum ou groupe privé</li>
                  </ul>
                </div>

                <div className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-2xl p-6 border border-blue-200">
                  <h3 className="font-bold text-blue-800 mb-3">📣 Te faire connaître</h3>
                  <ul className="space-y-2 text-blue-700 text-sm">
                    <li>• <strong>Instagram/TikTok</strong> : partage des exercices courts en vidéo</li>
                    <li>• <strong>Blog</strong> : articles SEO sur le bien-être</li>
                    <li>• <strong>YouTube</strong> : méditations guidées gratuites</li>
                    <li>• <strong>System.io</strong> : tunnel de vente avec lead magnet gratuit</li>
                    <li>• <strong>Affiliation</strong> : laisse d'autres vendre pour toi (commission)</li>
                    <li>• <strong>Partenariats</strong> : coachs, yoga, thérapie corporelle</li>
                  </ul>
                </div>

                <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl p-6 border border-amber-200">
                  <h3 className="font-bold text-amber-800 mb-3">🎯 Roadmap sur 6 mois</h3>
                  <div className="space-y-4">
                    <div className="flex gap-4">
                      <div className="flex-shrink-0 w-20 text-right">
                        <span className="text-xs font-bold text-amber-700">Semaine 1</span>
                      </div>
                      <div className="flex-1 bg-white/80 rounded-xl p-3">
                        <p className="text-amber-800 text-sm">Publier sur Vercel + créer page de vente System.io</p>
                      </div>
                    </div>
                    <div className="flex gap-4">
                      <div className="flex-shrink-0 w-20 text-right">
                        <span className="text-xs font-bold text-amber-700">Mois 1</span>
                      </div>
                      <div className="flex-1 bg-white/80 rounded-xl p-3">
                        <p className="text-amber-800 text-sm">Faire tester à 10 personnes, récolter les feedbacks</p>
                      </div>
                    </div>
                    <div className="flex gap-4">
                      <div className="flex-shrink-0 w-20 text-right">
                        <span className="text-xs font-bold text-amber-700">Mois 2</span>
                      </div>
                      <div className="flex-1 bg-white/80 rounded-xl p-3">
                        <p className="text-amber-800 text-sm">Lancer officiellement + commencer à communiquer sur les réseaux</p>
                      </div>
                    </div>
                    <div className="flex gap-4">
                      <div className="flex-shrink-0 w-20 text-right">
                        <span className="text-xs font-bold text-amber-700">Mois 3-4</span>
                      </div>
                      <div className="flex-1 bg-white/80 rounded-xl p-3">
                        <p className="text-amber-800 text-sm">Ajouter des formations vidéo + audio méditations</p>
                      </div>
                    </div>
                    <div className="flex gap-4">
                      <div className="flex-shrink-0 w-20 text-right">
                        <span className="text-xs font-bold text-amber-700">Mois 5-6</span>
                      </div>
                      <div className="flex-1 bg-white/80 rounded-xl p-3">
                        <p className="text-amber-800 text-sm">Lancer la communauté + ateliers en direct</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-rose-50 to-pink-50 rounded-2xl p-6 border border-rose-200">
                  <h3 className="font-bold text-rose-800 mb-3">💰 Potentiel de revenus</h3>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="bg-white/80 rounded-xl p-4 text-center">
                      <p className="text-3xl font-bold text-rose-700">50</p>
                      <p className="text-rose-600 text-sm">abonnés</p>
                      <p className="text-rose-500 text-xs mt-1">≈ 495€/mois</p>
                    </div>
                    <div className="bg-white/80 rounded-xl p-4 text-center">
                      <p className="text-3xl font-bold text-rose-700">200</p>
                      <p className="text-rose-600 text-sm">abonnés</p>
                      <p className="text-rose-500 text-xs mt-1">≈ 1 980€/mois</p>
                    </div>
                    <div className="bg-white/80 rounded-xl p-4 text-center">
                      <p className="text-3xl font-bold text-rose-700">500</p>
                      <p className="text-rose-600 text-sm">abonnés</p>
                      <p className="text-rose-500 text-xs mt-1">≈ 4 950€/mois</p>
                    </div>
                  </div>
                  <p className="text-rose-600 text-xs mt-3 text-center">
                    * Basé sur un abonnement à 9,90€/mois
                  </p>
                </div>

                <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-6 border border-green-200">
                  <h3 className="font-bold text-green-800 mb-3">💡 Tes avantages uniques</h3>
                  <ul className="space-y-2 text-green-700 text-sm">
                    <li>✅ Tu as déjà une entreprise → pas de création à faire</li>
                    <li>✅ Tu as Stripe sur System.io → paiement déjà configuré</li>
                    <li>✅ Tu as une expertise en art, créativité, formation</li>
                    <li>✅ Le marché du bien-être est en pleine explosion</li>
                    <li>✅ Tu peux combiner art + développement personnel = unique !</li>
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Final message */}
        <div className="mt-12 bg-gradient-to-r from-purple-100 to-pink-100 rounded-3xl p-8 text-center border border-purple-200">
          <div className="text-4xl mb-4">✨</div>
          <h3 className="text-xl font-bold text-purple-800 mb-3">
            Tu as tout ce qu'il faut !
          </h3>
          <p className="text-purple-700 mb-4">
            Entreprise ✓ — Stripe ✓ — System.io ✓ — Application ✓<br/>
            Il ne te reste plus qu'à suivre les étapes une par une.
          </p>
          <p className="text-purple-600 text-sm">
            Commence par Vercel (20 minutes), puis connecte ton lien de paiement System.io, et lance-toi ! 🚀
          </p>
        </div>
      </div>
    </div>
  )
}

import { useState } from 'react'
import { Exercise } from '../types'
import { categories } from '../data'

interface ExerciseDetailProps {
  exercise: Exercise
  onBack: () => void
}

export default function ExerciseDetail({ exercise, onBack }: ExerciseDetailProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [completedSteps, setCompletedSteps] = useState<number[]>([])
  const [showTips, setShowTips] = useState<Record<number, boolean>>({})

  const cat = categories.find(c => c.id === exercise.category)
  const totalSteps = exercise.steps.length
  const progress = (completedSteps.length / totalSteps) * 100
  const isCompleted = completedSteps.length === totalSteps

  const toggleStep = (index: number) => {
    setCompletedSteps(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    )
  }

  const toggleTip = (index: number) => {
    setShowTips(prev => ({ ...prev, [index]: !prev[index] }))
  }

  return (
    <div className="min-h-screen px-4 py-12">
      {/* Decorative */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 w-72 h-72 bg-purple-200/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-80 h-80 bg-pink-200/20 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 max-w-3xl mx-auto">
        {/* Back button */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-500 hover:text-purple-600 transition-colors mb-6"
        >
          ← Retour à la bibliothèque
        </button>

        {/* Header */}
        <div className="bg-white/70 backdrop-blur-sm rounded-3xl p-8 shadow-xl shadow-purple-100/30 border border-white/80 mb-8">
          <div className="flex items-start gap-4 mb-6">
            <span className="text-5xl">{exercise.emoji}</span>
            <div className="flex-1">
              <span className={`text-xs px-3 py-1 rounded-full bg-gradient-to-r ${cat?.color} text-white font-medium inline-block mb-2`}>
                {cat?.emoji} {cat?.title}
              </span>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-800 mb-2">
                {exercise.title}
              </h1>
              <div className="flex flex-wrap items-center gap-3">
                <span className="text-sm text-gray-500">⏱️ {exercise.duration}</span>
                <span className="text-sm text-gray-500">📊 {exercise.difficulty}</span>
              </div>
            </div>
          </div>

          <p className="text-gray-600 text-lg mb-6">{exercise.description}</p>

          {/* Benefits */}
          <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-5 border border-purple-100">
            <h3 className="font-semibold text-purple-800 mb-3">✨ Bienfaits</h3>
            <div className="flex flex-wrap gap-2">
              {exercise.benefits.map((benefit, i) => (
                <span key={i} className="px-3 py-1.5 bg-white/80 rounded-full text-sm text-purple-700 border border-purple-100">
                  {benefit}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Progress */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-500">Progression</span>
            <span className="text-sm text-purple-600 font-medium">
              {completedSteps.length}/{totalSteps} étapes
            </span>
          </div>
          <div className="w-full h-3 bg-purple-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-purple-400 to-pink-400 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>

        {/* Steps */}
        <div className="space-y-4 mb-8">
          {exercise.steps.map((step, index) => (
            <div
              key={index}
              className={`bg-white/70 backdrop-blur-sm rounded-2xl border transition-all duration-300 ${
                completedSteps.includes(index)
                  ? 'border-green-200 bg-green-50/50'
                  : currentStep === index
                    ? 'border-purple-300 shadow-lg shadow-purple-100/50'
                    : 'border-gray-200'
              }`}
            >
              <div className="p-6">
                <div className="flex items-start gap-4">
                  {/* Step number / checkbox */}
                  <button
                    onClick={() => toggleStep(index)}
                    className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all ${
                      completedSteps.includes(index)
                        ? 'bg-green-400 text-white shadow-lg shadow-green-200/50'
                        : currentStep === index
                          ? 'bg-purple-500 text-white shadow-lg shadow-purple-200/50'
                          : 'bg-gray-200 text-gray-500'
                    }`}
                  >
                    {completedSteps.includes(index) ? '✓' : index + 1}
                  </button>

                  <div className="flex-1">
                    <h3 className={`font-bold text-lg mb-2 ${
                      completedSteps.includes(index) ? 'text-green-700' : 'text-gray-800'
                    }`}>
                      {step.title}
                    </h3>
                    <p className={`text-gray-600 leading-relaxed ${
                      completedSteps.includes(index) ? 'text-green-600' : ''
                    }`}>
                      {step.description}
                    </p>

                    {/* Tip */}
                    {step.tip && (
                      <div className="mt-3">
                        <button
                          onClick={() => toggleTip(index)}
                          className="text-sm text-purple-500 hover:text-purple-700 font-medium transition-colors"
                        >
                          {showTips[index] ? '💡 Masquer le conseil' : '💡 Voir un conseil'}
                        </button>
                        {showTips[index] && (
                          <div className="mt-2 p-3 bg-amber-50 rounded-xl border border-amber-200 text-sm text-amber-800 animate-fadeIn">
                            {step.tip}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Completion message */}
        {isCompleted && (
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-3xl p-8 border border-green-200 text-center mb-8 animate-fadeIn">
            <div className="text-5xl mb-4">🎉</div>
            <h2 className="text-2xl font-bold text-green-800 mb-3">
              Bravo ! Tu as terminé cet exercice !
            </h2>
            <p className="text-green-700 text-lg mb-4">
              Tu viens de prendre un moment pour toi. C'est un acte d'amour envers toi-même.
            </p>
            <p className="text-green-600">
              N'oublie pas : tu peux revenir sur cet exercice autant de fois que tu en as besoin. 💚
            </p>
          </div>
        )}

        {/* Navigation */}
        {!isCompleted && (
          <div className="flex items-center justify-between bg-white/50 rounded-2xl p-4 border border-gray-200">
            <button
              onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
              disabled={currentStep === 0}
              className="px-4 py-2 text-gray-500 hover:text-purple-600 disabled:opacity-30 transition-colors"
            >
              ← Précédent
            </button>
            <button
              onClick={() => {
                toggleStep(currentStep)
                if (currentStep < totalSteps - 1) {
                  setCurrentStep(currentStep + 1)
                }
              }}
              className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl font-semibold shadow-lg shadow-purple-300/50 hover:shadow-xl hover:scale-105 transition-all"
            >
              {currentStep === totalSteps - 1 ? 'Terminer ✨' : 'Étape suivante →'}
            </button>
          </div>
        )}

        {/* Back to library */}
        <div className="mt-8 text-center">
          <button
            onClick={onBack}
            className="text-gray-500 hover:text-purple-600 transition-colors"
          >
            ← Retour à la bibliothèque d'exercices
          </button>
        </div>
      </div>
    </div>
  )
}

import { useState } from 'react'

interface WelcomeProps {
  onStart: (name: string) => void
  onShowGuide?: () => void
}

export default function Welcome({ onStart, onShowGuide }: WelcomeProps) {
  const [name, setName] = useState('')
  const [showInput, setShowInput] = useState(false)

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-12">
      {/* Decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-72 h-72 bg-purple-200/30 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-pink-200/30 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-200/20 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 max-w-2xl mx-auto text-center">
        {/* Logo */}
        <div className="mb-8">
          <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-gradient-to-br from-purple-200 to-pink-200 shadow-xl shadow-purple-200/50 mb-6">
            <span className="text-5xl">🌿</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-700 via-pink-600 to-amber-600 bg-clip-text text-transparent mb-2">
            Élan Vital
          </h1>
          <p className="text-lg text-gray-500 font-light">Bien-être & Développement personnel</p>
        </div>

        {/* Message d'accueil */}
        <div className="bg-white/60 backdrop-blur-sm rounded-3xl p-8 md:p-10 shadow-xl shadow-purple-100/50 border border-white/80 mb-8">
          <p className="text-xl md:text-2xl text-gray-700 leading-relaxed mb-6">
            Bienvenue, toi. ✨
          </p>
          <p className="text-gray-600 leading-relaxed mb-4">
            Tu as envie de te sentir mieux, de te reconnecter à toi-même, de donner un nouvel élan à ta vie ? Tu es au bon endroit.
          </p>
          <p className="text-gray-600 leading-relaxed mb-4">
            Ici, pas de jugement, pas de pression. Juste des <strong className="text-purple-700">exercices simples et bienveillants</strong> pour t'aider à :
          </p>
          <div className="grid grid-cols-2 gap-3 my-6">
            <div className="bg-purple-50 rounded-xl p-3 border border-purple-100">
              <span className="text-lg">🧘</span>
              <p className="text-sm text-purple-700 mt-1">Mieux te connaître</p>
            </div>
            <div className="bg-pink-50 rounded-xl p-3 border border-pink-100">
              <span className="text-lg">💪</span>
              <p className="text-sm text-pink-700 mt-1">Retrouver ta force</p>
            </div>
            <div className="bg-amber-50 rounded-xl p-3 border border-amber-100">
              <span className="text-lg">🌱</span>
              <p className="text-sm text-amber-700 mt-1">Grandir chaque jour</p>
            </div>
            <div className="bg-green-50 rounded-xl p-3 border border-green-100">
              <span className="text-lg">☀️</span>
              <p className="text-sm text-green-700 mt-1">Vivre pleinement</p>
            </div>
          </div>
          <p className="text-gray-600 leading-relaxed">
            Cet espace est le tien. Prends ce dont tu as besoin, à ton rythme.
          </p>
        </div>

        {/* CTA */}
        {!showInput ? (
          <button
            onClick={() => setShowInput(true)}
            className="group px-8 py-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-2xl font-semibold text-lg shadow-xl shadow-purple-300/50 hover:shadow-2xl hover:shadow-purple-400/50 hover:scale-105 transition-all duration-300"
          >
            <span className="flex items-center gap-3">
              Commencer mon parcours
              <span className="group-hover:translate-x-1 transition-transform">→</span>
            </span>
          </button>
        ) : (
          <div className="bg-white/60 backdrop-blur-sm rounded-3xl p-8 shadow-xl shadow-purple-100/50 border border-white/80 animate-fadeIn">
            <p className="text-gray-600 mb-4">
              Comment souhaites-tu que je t'appelle ? <span className="text-gray-400">(optionnel)</span>
            </p>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ton prénom ou un surnom..."
              className="w-full px-6 py-4 bg-white/80 rounded-xl border border-purple-200 focus:border-purple-400 focus:ring-2 focus:ring-purple-200 outline-none text-gray-700 text-lg transition-all mb-4"
              onKeyDown={(e) => e.key === 'Enter' && onStart(name)}
            />
            <button
              onClick={() => onStart(name)}
              className="w-full px-8 py-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl font-semibold text-lg shadow-lg shadow-purple-300/50 hover:shadow-xl hover:scale-[1.02] transition-all duration-300"
            >
              C'est parti 🌸
            </button>
          </div>
        )}

        {/* Note */}
        <div className="mt-10 p-4 bg-green-50/80 rounded-2xl border border-green-200/50">
          <p className="text-sm text-green-800">
            🌿 <strong>Élan Vital</strong> est un outil de développement personnel et de bien-être. 
            Il te propose des exercices de méditation, d'ancrage, de créativité et de réflexion pour t'accompagner dans ton cheminement personnel.
          </p>
        </div>

        {/* Bouton guide */}
        {onShowGuide && (
          <button
            onClick={onShowGuide}
            className="mt-6 px-4 py-2 text-sm text-gray-400 hover:text-purple-600 transition-colors underline decoration-dotted"
          >
            📋 Guide de lancement et monétisation
          </button>
        )}
      </div>
    </div>
  )
}

import { useState } from 'react'
import { questions } from '../data'
import { Answer } from '../types'

interface QuestionnaireProps {
  onComplete: (answers: Answer[]) => void
}

export default function Questionnaire({ onComplete }: QuestionnaireProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Answer[]>([])
  const [selectedValues, setSelectedValues] = useState<string[]>([])
  const [transitioning, setTransitioning] = useState(false)

  const question = questions[currentQuestion]
  const progress = ((currentQuestion) / questions.length) * 100

  const handleSelect = (value: string) => {
    if (question.type === 'multiple') {
      setSelectedValues(prev => 
        prev.includes(value) 
          ? prev.filter(v => v !== value)
          : [...prev, value]
      )
    } else {
      setSelectedValues([value])
    }
  }

  const handleNext = () => {
    if (selectedValues.length === 0) return

    const newAnswer: Answer = {
      questionId: question.id,
      value: question.type === 'multiple' ? selectedValues : selectedValues[0]
    }

    const newAnswers = [...answers, newAnswer]

    if (currentQuestion < questions.length - 1) {
      setTransitioning(true)
      setTimeout(() => {
        setAnswers(newAnswers)
        setCurrentQuestion(currentQuestion + 1)
        setSelectedValues([])
        setTransitioning(false)
      }, 300)
    } else {
      onComplete(newAnswers)
    }
  }

  const handleBack = () => {
    if (currentQuestion > 0) {
      setTransitioning(true)
      setTimeout(() => {
        setCurrentQuestion(currentQuestion - 1)
        const prevAnswer = answers[currentQuestion - 1]
        if (prevAnswer) {
          setSelectedValues(Array.isArray(prevAnswer.value) ? prevAnswer.value : [prevAnswer.value as string])
        }
        setAnswers(answers.slice(0, -1))
        setTransitioning(false)
      }, 300)
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-12">
      {/* Decorative */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 right-20 w-64 h-64 bg-purple-200/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 left-20 w-80 h-80 bg-pink-200/20 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 w-full max-w-2xl mx-auto">
        {/* Progress bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-500">Question {currentQuestion + 1} sur {questions.length}</span>
            <span className="text-sm text-purple-600 font-medium">{Math.round(progress)}%</span>
          </div>
          <div className="w-full h-2 bg-purple-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-purple-400 to-pink-400 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>

        {/* Question card */}
        <div className={`bg-white/70 backdrop-blur-sm rounded-3xl p-8 md:p-10 shadow-xl shadow-purple-100/30 border border-white/80 transition-all duration-300 ${transitioning ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'}`}>
          {/* Question text */}
          <div className="mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-3">
              {question.text}
            </h2>
            {question.subtitle && (
              <p className="text-gray-500 text-lg italic">{question.subtitle}</p>
            )}
          </div>

          {/* Options */}
          <div className="space-y-3 mb-8">
            {question.options?.map((option) => (
              <button
                key={option.value}
                onClick={() => handleSelect(option.value)}
                className={`w-full text-left p-4 md:p-5 rounded-2xl border-2 transition-all duration-200 ${
                  selectedValues.includes(option.value)
                    ? 'border-purple-400 bg-purple-50 shadow-md shadow-purple-100'
                    : 'border-gray-200 bg-white/50 hover:border-purple-200 hover:bg-purple-50/50'
                }`}
              >
                <div className="flex items-center gap-4">
                  <span className="text-2xl">{option.emoji}</span>
                  <span className={`text-base md:text-lg ${selectedValues.includes(option.value) ? 'text-purple-800 font-medium' : 'text-gray-700'}`}>
                    {option.label}
                  </span>
                  {selectedValues.includes(option.value) && (
                    <span className="ml-auto text-purple-500">✓</span>
                  )}
                </div>
              </button>
            ))}
          </div>

          {question.type === 'multiple' && selectedValues.length > 0 && (
            <p className="text-sm text-gray-500 text-center mb-4">
              Tu peux sélectionner plusieurs réponses ✨
            </p>
          )}

          {/* Navigation */}
          <div className="flex items-center justify-between">
            <button
              onClick={handleBack}
              disabled={currentQuestion === 0}
              className="px-5 py-3 text-gray-500 hover:text-gray-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              ← Retour
            </button>
            <button
              onClick={handleNext}
              disabled={selectedValues.length === 0}
              className="px-8 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl font-semibold shadow-lg shadow-purple-300/50 hover:shadow-xl hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
            >
              {currentQuestion === questions.length - 1 ? 'Découvrir mes exercices 🌟' : 'Suivant →'}
            </button>
          </div>
        </div>

        {/* Encouragement */}
        <p className="text-center text-gray-400 text-sm mt-6">
          💜 Prends ton temps. Il n'y a pas de bonne ou mauvaise réponse.
        </p>
      </div>
    </div>
  )
}

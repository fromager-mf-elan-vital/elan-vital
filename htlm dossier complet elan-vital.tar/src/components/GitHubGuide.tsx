import { useState } from 'react'

interface GitHubGuideProps {
  onBack: () => void
}

export default function GitHubGuide({ onBack }: GitHubGuideProps) {
  const [currentStep, setCurrentStep] = useState(0)

  const steps = [
    {
      title: "Aller sur GitHub",
      icon: "🌐",
      description: "Ouvre ton navigateur et va sur github.com"
    },
    {
      title: "Créer un compte (ou se connecter)",
      icon: "👤",
      description: "Si tu n'as pas de compte, crée-en un. Sinon, connecte-toi."
    },
    {
      title: "Cliquer sur le bouton '+'",
      icon: "➕",
      description: "En haut à droite de l'écran, clique sur le '+' puis 'New repository'"
    },
    {
      title: "Remplir le formulaire",
      icon: "📝",
      description: "Donne un nom à ton repo et choisis 'Private'"
    },
    {
      title: "Uploader ton code",
      icon: "📤",
      description: "Glisse tes fichiers dans la zone prévue"
    },
    {
      title: "Valider !",
      icon: "✅",
      description: "Clique sur 'Commit changes'. Ton code est sur GitHub !"
    }
  ]

  return (
    <div className="min-h-screen px-4 py-12">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 w-72 h-72 bg-gray-200/30 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-80 h-80 bg-blue-200/20 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 max-w-4xl mx-auto">
        {/* Back */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-500 hover:text-purple-600 transition-colors mb-6"
        >
          ← Retour au guide
        </button>

        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-3">
            🐙 Créer ton repo GitHub
          </h1>
          <p className="text-gray-600 text-lg">
            Suis chaque étape, c'est plus simple qu'il n'y paraît !
          </p>
        </div>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-500">Étape {currentStep + 1} sur {steps.length}</span>
            <span className="text-sm text-purple-600 font-medium">{Math.round(((currentStep + 1) / steps.length) * 100)}%</span>
          </div>
          <div className="w-full h-3 bg-purple-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-purple-400 to-pink-400 rounded-full transition-all duration-500"
              style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            ></div>
          </div>
          {/* Step indicators */}
          <div className="flex justify-between mt-2">
            {steps.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentStep(i)}
                className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                  i === currentStep
                    ? 'bg-purple-500 text-white scale-110'
                    : i < currentStep
                      ? 'bg-green-400 text-white'
                      : 'bg-gray-200 text-gray-500'
                }`}
              >
                {i < currentStep ? '✓' : i + 1}
              </button>
            ))}
          </div>
        </div>

        {/* Step content */}
        <div className="bg-white/70 backdrop-blur-sm rounded-3xl p-8 shadow-xl shadow-purple-100/30 border border-white/80 animate-fadeIn">
          <div className="flex items-center gap-4 mb-6">
            <span className="text-4xl">{steps[currentStep].icon}</span>
            <div>
              <h2 className="text-2xl font-bold text-gray-800">
                Étape {currentStep + 1} : {steps[currentStep].title}
              </h2>
              <p className="text-gray-500">{steps[currentStep].description}</p>
            </div>
          </div>

          {/* ÉTAPE 1 : Aller sur GitHub */}
          {currentStep === 0 && (
            <div className="space-y-6">
              <div className="bg-gray-50 rounded-2xl p-6 border border-gray-200">
                <p className="text-gray-700 mb-4">Ouvre ton navigateur (Chrome, Firefox, Safari...) et tape cette adresse :</p>
                <div className="bg-white rounded-xl p-4 border-2 border-gray-300 flex items-center gap-3">
                  <span className="text-gray-400">🔒</span>
                  <code className="text-lg text-blue-600 font-mono font-bold">https://github.com</code>
                </div>
                <p className="text-gray-500 text-sm mt-3">Appuie sur Entrée. Tu vas arriver sur la page d'accueil de GitHub.</p>
              </div>

              {/* Mockup GitHub homepage */}
              <div className="rounded-xl overflow-hidden border border-gray-300 shadow-lg">
                <div className="bg-gray-900 px-4 py-3 flex items-center gap-3">
                  <div className="flex gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  </div>
                  <div className="flex-1 bg-gray-700 rounded-md px-3 py-1 text-gray-300 text-xs font-mono">
                    github.com
                  </div>
                </div>
                <div className="bg-gray-900 p-6">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center">
                        <span className="text-gray-900 text-sm font-bold">🐙</span>
                      </div>
                      <span className="text-white font-bold">GitHub</span>
                    </div>
                    <div className="flex gap-2">
                      <div className="px-3 py-1.5 bg-gray-700 rounded-md text-white text-xs">Sign in</div>
                      <div className="px-3 py-1.5 bg-green-600 rounded-md text-white text-xs font-bold">Sign up</div>
                    </div>
                  </div>
                  <div className="text-center py-8">
                    <p className="text-white text-2xl font-bold mb-2">Let's build from here</p>
                    <p className="text-gray-400">The world's most widely adopted AI-powered developer platform</p>
                  </div>
                </div>
              </div>

              <div className="bg-green-50 rounded-xl p-4 border border-green-200">
                <p className="text-green-800 text-sm">
                  ✅ <strong>C'est fait ?</strong> Tu es sur la page d'accueil de GitHub. Passe à l'étape suivante !
                </p>
              </div>
            </div>
          )}

          {/* ÉTAPE 2 : Créer un compte */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <div className="bg-blue-50 rounded-2xl p-6 border border-blue-200">
                <h3 className="font-bold text-blue-800 mb-3">🆕 Si tu n'as PAS de compte :</h3>
                <ol className="space-y-3 text-blue-700 text-sm">
                  <li className="flex gap-2">
                    <span className="font-bold text-blue-800">1.</span>
                    <span>Clique sur le bouton vert <strong>"Sign up"</strong> en haut à droite</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-bold text-blue-800">2.</span>
                    <span>Entre ton <strong>adresse email</strong> (celle de ton entreprise)</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-bold text-blue-800">3.</span>
                    <span>Crée un <strong>mot de passe</strong> solide (min 8 caractères)</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-bold text-blue-800">4.</span>
                    <span>Choisis un <strong>nom d'utilisateur</strong> (ex: elan-vital, ton-nom...)</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-bold text-blue-800">5.</span>
                    <span>Suis les étapes de vérification (email + puzzle)</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-bold text-blue-800">6.</span>
                    <span>Choisis le plan <strong>Free</strong> (gratuit, largement suffisant)</span>
                  </li>
                </ol>
              </div>

              {/* Mockup Sign up */}
              <div className="rounded-xl overflow-hidden border border-gray-300 shadow-lg">
                <div className="bg-gray-100 px-4 py-3 flex items-center gap-3 border-b">
                  <div className="flex gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  </div>
                  <div className="flex-1 bg-white rounded-md px-3 py-1 text-gray-500 text-xs font-mono border">
                    github.com/signup
                  </div>
                </div>
                <div className="bg-white p-8">
                  <div className="max-w-sm mx-auto">
                    <div className="text-center mb-6">
                      <div className="w-12 h-12 bg-gray-900 rounded-full mx-auto flex items-center justify-center mb-3">
                        <span className="text-white text-lg">🐙</span>
                      </div>
                      <h3 className="font-bold text-gray-900 text-xl">Join GitHub</h3>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <label className="text-xs text-gray-600 font-medium">Email</label>
                        <div className="w-full border-2 border-gray-300 rounded-md px-3 py-2 text-sm text-gray-400">ton@email.com</div>
                      </div>
                      <div>
                        <label className="text-xs text-gray-600 font-medium">Password</label>
                        <div className="w-full border-2 border-gray-300 rounded-md px-3 py-2 text-sm text-gray-400">••••••••••</div>
                      </div>
                      <div>
                        <label className="text-xs text-gray-600 font-medium">Username</label>
                        <div className="w-full border-2 border-green-400 rounded-md px-3 py-2 text-sm text-green-700 font-mono">elan-vital ✨</div>
                      </div>
                      <button className="w-full bg-green-600 text-white rounded-md py-2.5 font-bold text-sm mt-4">
                        Continue →
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-amber-50 rounded-xl p-4 border border-amber-200">
                <p className="text-amber-800 text-sm">
                  🔑 <strong>Si tu as DÉJÀ un compte :</strong> clique simplement sur "Sign in" et connecte-toi. Passe directement à l'étape 3 !
                </p>
              </div>

              <div className="bg-green-50 rounded-xl p-4 border border-green-200">
                <p className="text-green-800 text-sm">
                  ✅ <strong>C'est fait ?</strong> Tu es connecté·e à GitHub. Passe à l'étape suivante !
                </p>
              </div>
            </div>
          )}

          {/* ÉTAPE 3 : Cliquer sur '+' */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <div className="bg-purple-50 rounded-2xl p-6 border border-purple-200">
                <p className="text-purple-700 mb-4">
                  Une fois connecté·e, regarde <strong>en haut à droite</strong> de l'écran. Tu vas voir une petite icône <strong>"+"</strong> (un plus).
                </p>
                <ol className="space-y-2 text-purple-700 text-sm">
                  <li>1. Clique sur le <strong>"+"</strong></li>
                  <li>2. Un menu déroulant apparaît</li>
                  <li>3. Clique sur <strong>"New repository"</strong></li>
                </ol>
              </div>

              {/* Mockup GitHub navbar */}
              <div className="rounded-xl overflow-hidden border border-gray-300 shadow-lg">
                <div className="bg-gray-900 px-4 py-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-7 h-7 bg-white rounded-full flex items-center justify-center">
                        <span className="text-xs">🐙</span>
                      </div>
                      <div className="bg-gray-700 rounded-md px-3 py-1 text-gray-300 text-xs w-48">
                        Search or jump to...
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-gray-300 text-xs">🔔</div>
                      <div className="text-gray-300 text-xs">▼</div>
                      {/* Le bouton + */}
                      <div className="relative">
                        <div className="w-7 h-7 bg-gray-700 rounded-full flex items-center justify-center border-2 border-green-400 animate-pulse">
                          <span className="text-white text-sm font-bold">+</span>
                        </div>
                        {/* Menu déroulant */}
                        <div className="absolute right-0 top-9 bg-white rounded-lg shadow-xl border p-2 w-56 z-10">
                          <div className="px-3 py-2 hover:bg-gray-100 rounded text-sm text-gray-700 cursor-pointer">New repository</div>
                          <div className="px-3 py-2 hover:bg-gray-100 rounded text-sm text-gray-700 cursor-pointer">Import repository</div>
                          <div className="px-3 py-2 hover:bg-gray-100 rounded text-sm text-gray-700 cursor-pointer">New gist</div>
                          <div className="px-3 py-2 hover:bg-gray-100 rounded text-sm text-gray-700 cursor-pointer">New organization</div>
                        </div>
                      </div>
                      <div className="w-7 h-7 bg-purple-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                        T
                      </div>
                    </div>
                  </div>
                </div>
                <div className="bg-white p-8 min-h-[100px] flex items-center justify-center">
                  <p className="text-gray-400 text-sm">↑ Clique sur le <strong className="text-green-500">+</strong> puis <strong className="text-green-500">"New repository"</strong></p>
                </div>
              </div>

              <div className="bg-green-50 rounded-xl p-4 border border-green-200">
                <p className="text-green-800 text-sm">
                  ✅ <strong>Clique sur "New repository"</strong> et passe à l'étape suivante !
                </p>
              </div>
            </div>
          )}

          {/* ÉTAPE 4 : Remplir le formulaire */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <div className="bg-pink-50 rounded-2xl p-6 border border-pink-200">
                <p className="text-pink-700 mb-4">
                  Tu es sur la page "Create a new repository". Remplis le formulaire comme ceci :
                </p>
              </div>

              {/* Mockup formulaire */}
              <div className="rounded-xl overflow-hidden border border-gray-300 shadow-lg">
                <div className="bg-gray-100 px-4 py-3 border-b">
                  <div className="flex items-center gap-2">
                    <span className="text-gray-500 text-sm">🐙</span>
                    <span className="text-gray-700 text-sm font-bold">Create a new repository</span>
                  </div>
                </div>
                <div className="bg-white p-6 space-y-5">
                  {/* Owner */}
                  <div>
                    <label className="text-sm font-bold text-gray-800 mb-1 block">Owner *</label>
                    <div className="flex items-center gap-2">
                      <div className="border-2 border-gray-300 rounded-md px-3 py-2 text-sm text-gray-600 flex-1">
                        ton-username
                      </div>
                      <span className="text-gray-400">/</span>
                      <div className="border-2 border-green-400 rounded-md px-3 py-2 text-sm text-green-700 font-mono font-bold flex-1">
                        elan-vital ✨
                      </div>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">👆 C'est le nom de ton repo. Mets <strong>"elan-vital"</strong></p>
                  </div>

                  {/* Description */}
                  <div>
                    <label className="text-sm font-bold text-gray-800 mb-1 block">Description <span className="text-gray-400 font-normal">(optional)</span></label>
                    <div className="border-2 border-gray-300 rounded-md px-3 py-2 text-sm text-gray-600">
                      Application de bien-être et développement personnel ✨
                    </div>
                  </div>

                  {/* Visibility */}
                  <div>
                    <label className="text-sm font-bold text-gray-800 mb-2 block">Visibility *</label>
                    <div className="space-y-2">
                      <div className="border-2 border-gray-300 rounded-lg p-3 flex items-start gap-3">
                        <div className="w-4 h-4 border-2 border-gray-400 rounded-full mt-0.5"></div>
                        <div>
                          <p className="font-semibold text-gray-700 text-sm">🌐 Public</p>
                          <p className="text-gray-500 text-xs">Anyone on the internet can see this repository.</p>
                        </div>
                      </div>
                      <div className="border-2 border-green-400 bg-green-50 rounded-lg p-3 flex items-start gap-3">
                        <div className="w-4 h-4 border-2 border-green-500 rounded-full mt-0.5 flex items-center justify-center">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        </div>
                        <div>
                          <p className="font-semibold text-green-800 text-sm">🔒 Private ← CHOISIS CELUI-CI !</p>
                          <p className="text-green-600 text-xs">You choose who can see and commit to this repository.</p>
                        </div>
                      </div>
                    </div>
                    <p className="text-xs text-red-500 mt-2 font-medium">⚠️ IMPORTANT : Coche "Private" pour protéger ton code !</p>
                  </div>

                  {/* Checkboxes */}
                  <div className="space-y-2">
                    <label className="flex items-center gap-2 text-sm text-gray-700">
                      <input type="checkbox" defaultChecked className="rounded" />
                      Add a README file
                    </label>
                  </div>

                  {/* Bouton */}
                  <button className="bg-green-600 text-white rounded-md px-4 py-2 font-bold text-sm hover:bg-green-700">
                    Create repository
                  </button>
                </div>
              </div>

              <div className="bg-amber-50 rounded-xl p-4 border border-amber-200">
                <p className="text-amber-800 text-sm">
                  📝 <strong>Récapitulatif :</strong><br/>
                  • Nom : <code className="bg-amber-100 px-1 rounded">elan-vital</code><br/>
                  • Description : "Application de bien-être et développement personnel"<br/>
                  • Visibility : <strong>Private 🔒</strong><br/>
                  • Coche "Add a README file"
                </p>
              </div>

              <div className="bg-green-50 rounded-xl p-4 border border-green-200">
                <p className="text-green-800 text-sm">
                  ✅ <strong>Remplis le formulaire</strong> comme montré ci-dessus, mais <strong>ne clique PAS encore sur "Create repository"</strong>. On va d'abord uploader le code à l'étape suivante.
                </p>
              </div>
            </div>
          )}

          {/* ÉTAPE 5 : Uploader le code */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <div className="bg-blue-50 rounded-2xl p-6 border border-blue-200">
                <h3 className="font-bold text-blue-800 mb-3">📤 Deux options pour uploader ton code :</h3>
                
                <div className="space-y-4">
                  <div className="bg-white rounded-xl p-4 border border-blue-200">
                    <p className="font-bold text-blue-800 mb-2">Option A : Via l'interface GitHub (le plus simple)</p>
                    <ol className="space-y-2 text-blue-700 text-sm">
                      <li>1. Crée d'abord le repo (clique "Create repository")</li>
                      <li>2. Sur la page du repo, clique <strong>"Add file"</strong> → <strong>"Upload files"</strong></li>
                      <li>3. Glisse tous les fichiers de ton projet dans la zone</li>
                      <li>4. Clique <strong>"Commit changes"</strong></li>
                    </ol>
                  </div>

                  <div className="bg-white rounded-xl p-4 border border-blue-200">
                    <p className="font-bold text-blue-800 mb-2">Option B : Via le terminal (plus rapide si tu es à l'aise)</p>
                    <div className="bg-gray-900 rounded-lg p-4 text-green-300 text-xs font-mono space-y-1">
                      <p className="text-gray-500"># Ouvre un terminal dans le dossier de ton projet</p>
                      <p>git init</p>
                      <p>git add .</p>
                      <p>git commit -m "Premier commit"</p>
                      <p>git branch -M main</p>
                      <p className="text-gray-500"># Remplace TON-USER par ton nom d'utilisateur GitHub</p>
                      <p>git remote add origin https://github.com/<span className="text-yellow-300">TON-USER</span>/elan-vital.git</p>
                      <p>git push -u origin main</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Mockup upload */}
              <div className="rounded-xl overflow-hidden border border-gray-300 shadow-lg">
                <div className="bg-gray-100 px-4 py-3 border-b">
                  <span className="text-gray-700 text-sm font-bold">📤 Upload files</span>
                </div>
                <div className="bg-white p-6">
                  <div className="border-2 border-dashed border-blue-300 rounded-xl p-8 text-center bg-blue-50/50">
                    <div className="text-4xl mb-3">📁</div>
                    <p className="text-blue-700 font-semibold mb-2">
                      Drag files here to upload
                    </p>
                    <p className="text-blue-500 text-sm mb-4">or</p>
                    <button className="bg-blue-600 text-white rounded-md px-4 py-2 text-sm font-medium">
                      choose your files
                    </button>
                    <div className="mt-4 text-left bg-white rounded-lg p-3 border">
                      <p className="text-xs text-gray-500 mb-2">Fichiers à uploader :</p>
                      <div className="space-y-1 text-xs font-mono text-gray-600">
                        <p>📄 index.html</p>
                        <p>📄 package.json</p>
                        <p>📄 vite.config.ts</p>
                        <p>📁 src/</p>
                        <p className="pl-4">📄 App.tsx</p>
                        <p className="pl-4">📄 main.tsx</p>
                        <p className="pl-4">📄 index.css</p>
                        <p className="pl-4">📁 components/</p>
                        <p className="pl-4">📄 types.ts</p>
                        <p className="pl-4">📄 data.ts</p>
                        <p>📁 public/</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-amber-50 rounded-xl p-4 border border-amber-200">
                <p className="text-amber-800 text-sm">
                  💡 <strong>Conseil :</strong> Si tu n'es pas à l'aise avec le terminal, utilise l'Option A (glisser-déposer). C'est plus visuel et plus simple !
                </p>
              </div>

              <div className="bg-green-50 rounded-xl p-4 border border-green-200">
                <p className="text-green-800 text-sm">
                  ✅ <strong>Une fois les fichiers uploadés</strong>, clique sur "Commit changes" en bas de page. Ton code est maintenant sur GitHub !
                </p>
              </div>
            </div>
          )}

          {/* ÉTAPE 6 : Valider */}
          {currentStep === 5 && (
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-8 border border-green-200 text-center">
                <div className="text-6xl mb-4">🎉</div>
                <h3 className="text-2xl font-bold text-green-800 mb-3">
                  Bravo ! Ton repo est créé !
                </h3>
                <p className="text-green-700 mb-4">
                  Ton code est maintenant en sécurité sur GitHub, dans un repo privé.
                </p>
              </div>

              {/* Mockup repo créé */}
              <div className="rounded-xl overflow-hidden border border-gray-300 shadow-lg">
                <div className="bg-gray-100 px-4 py-3 border-b">
                  <div className="flex items-center gap-2">
                    <span className="text-gray-500">🔒</span>
                    <span className="text-blue-600 text-sm font-bold">ton-username</span>
                    <span className="text-gray-400">/</span>
                    <span className="text-blue-600 text-sm font-bold">elan-vital</span>
                    <span className="ml-2 px-2 py-0.5 bg-gray-200 rounded-full text-xs text-gray-600">Private</span>
                  </div>
                </div>
                <div className="bg-white p-6">
                  <div className="flex items-center gap-2 mb-4 pb-3 border-b">
                    <span className="text-sm text-gray-600">📁</span>
                    <span className="text-sm text-gray-600">src</span>
                    <span className="text-sm text-gray-600 ml-4">📄</span>
                    <span className="text-sm text-gray-600">index.html</span>
                    <span className="text-sm text-gray-600 ml-4">📄</span>
                    <span className="text-sm text-gray-600">package.json</span>
                  </div>
                  <div className="bg-green-50 rounded-lg p-4 border border-green-200">
                    <p className="text-green-800 text-sm font-medium">
                      ✅ Repository created successfully!
                    </p>
                    <p className="text-green-600 text-xs mt-1">
                      Your code is safely stored on GitHub.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-purple-50 rounded-2xl p-6 border border-purple-200">
                <h3 className="font-bold text-purple-800 mb-3">🚀 Prochaine étape : Vercel !</h3>
                <p className="text-purple-700 mb-3">Maintenant que ton code est sur GitHub, tu peux le déployer sur Vercel en 3 clics :</p>
                <ol className="space-y-2 text-purple-700 text-sm">
                  <li>1. Va sur <strong>vercel.com</strong></li>
                  <li>2. Connecte-toi avec GitHub</li>
                  <li>3. Importe ton repo "elan-vital"</li>
                  <li>4. Clique "Deploy"</li>
                  <li>5. 🎉 Ton site est en ligne !</li>
                </ol>
              </div>

              <div className="bg-amber-50 rounded-xl p-4 border border-amber-200">
                <p className="text-amber-800 text-sm">
                  💡 <strong>À retenir :</strong> À chaque fois que tu modifies ton code et que tu fais <code className="bg-amber-100 px-1 rounded">git push</code>, Vercel met automatiquement ton site à jour. Magique ! ✨
                </p>
              </div>
            </div>
          )}

          {/* Navigation buttons */}
          <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-200">
            <button
              onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
              disabled={currentStep === 0}
              className="px-5 py-3 text-gray-500 hover:text-purple-600 disabled:opacity-30 disabled:cursor-not-allowed transition-colors font-medium"
            >
              ← Précédent
            </button>
            
            {currentStep < steps.length - 1 ? (
              <button
                onClick={() => setCurrentStep(currentStep + 1)}
                className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl font-semibold shadow-lg shadow-purple-300/50 hover:shadow-xl hover:scale-105 transition-all"
              >
                Étape suivante →
              </button>
            ) : (
              <button
                onClick={onBack}
                className="px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl font-semibold shadow-lg shadow-green-300/50 hover:shadow-xl hover:scale-105 transition-all"
              >
                🚀 Passer à Vercel !
              </button>
            )}
          </div>
        </div>

        {/* Récap rapide */}
        <div className="mt-8 bg-white/50 rounded-2xl p-6 border border-white/80">
          <h3 className="font-bold text-gray-800 mb-3 text-center">📋 Récap rapide</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {steps.map((step, i) => (
              <button
                key={i}
                onClick={() => setCurrentStep(i)}
                className={`p-3 rounded-xl text-left transition-all ${
                  i === currentStep
                    ? 'bg-purple-100 border-2 border-purple-300'
                    : i < currentStep
                      ? 'bg-green-50 border border-green-200'
                      : 'bg-gray-50 border border-gray-200'
                }`}
              >
                <span className="text-lg">{step.icon}</span>
                <p className={`text-xs mt-1 font-medium ${
                  i === currentStep ? 'text-purple-700' : i < currentStep ? 'text-green-700' : 'text-gray-500'
                }`}>
                  {step.title}
                </p>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

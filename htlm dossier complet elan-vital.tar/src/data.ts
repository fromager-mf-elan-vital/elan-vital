import { Exercise, Question, CategoryInfo } from './types'

export const categories: CategoryInfo[] = [
  {
    id: 'meditation',
    title: 'Méditation',
    emoji: '🧘',
    description: 'Apprends à apaiser ton mental, à te reconnecter à l\'instant présent et à cultiver la paix intérieure.',
    color: 'from-indigo-400 to-purple-500',
    bgColor: 'bg-indigo-50 border-indigo-200'
  },
  {
    id: 'ancrage',
    title: 'Ancrage & Présence',
    emoji: '🌳',
    description: 'Reconnecte-toi à ton corps, à la nature, et retrouve ta stabilité pour vivre pleinement le moment présent.',
    color: 'from-green-400 to-emerald-500',
    bgColor: 'bg-green-50 border-green-200'
  },
  {
    id: 'art-therapie',
    title: 'Créativité & Expression',
    emoji: '🎨',
    description: 'Exprime-toi par la création artistique pour développer ta conscience de toi et libérer ton potentiel créatif.',
    color: 'from-pink-400 to-rose-500',
    bgColor: 'bg-pink-50 border-pink-200'
  },
  {
    id: 'emotionnel',
    title: 'Connaissance de soi',
    emoji: '💛',
    description: 'Explore qui tu es vraiment, développe ton intelligence émotionnelle et cultive la confiance en toi.',
    color: 'from-amber-400 to-orange-500',
    bgColor: 'bg-amber-50 border-amber-200'
  }
]

export const questions: Question[] = [
  {
    id: 'envie',
    text: 'Qu\'est-ce qui t\'amène ici aujourd\'hui ?',
    subtitle: 'Prends un moment pour écouter ce qui te motive.',
    type: 'single',
    options: [
      { value: 'mieux-etre', label: 'Me sentir mieux au quotidien', emoji: '🌤️' },
      { value: 'confiance', label: 'Développer ma confiance en moi', emoji: '💪' },
      { value: 'sens', label: 'Trouver ou retrouver du sens', emoji: '🧭' },
      { value: 'stress', label: 'Mieux gérer mon stress', emoji: '🍃' },
      { value: 'creativite', label: 'Libérer ma créativité', emoji: '✨' },
      { value: 'equilibre', label: 'Retrouver un équilibre de vie', emoji: '⚖️' },
    ]
  },
  {
    id: 'besoin',
    text: 'De quoi aurais-tu le plus besoin en ce moment ?',
    subtitle: 'Écoute ce qui résonne le plus en toi.',
    type: 'single',
    options: [
      { value: 'calme', label: 'De calme et de sérénité', emoji: '☮️' },
      { value: 'energie', label: 'D\'énergie et de motivation', emoji: '⚡' },
      { value: 'clarte', label: 'De clarté et de vision', emoji: '🔮' },
      { value: 'creativite', label: 'D\'expression créative', emoji: '🎨' },
      { value: 'connexion', label: 'De me reconnecter à moi-même', emoji: '🤝' },
      { value: 'gratitude', label: 'De cultiver la gratitude', emoji: '🙏' },
    ]
  },
  {
    id: 'temps',
    text: 'Combien de temps peux-tu consacrer à un exercice ?',
    subtitle: 'Même 5 minutes comptent. L\'important, c\'est la régularité.',
    type: 'single',
    options: [
      { value: '5', label: '5 minutes', emoji: '⏱️' },
      { value: '10', label: '10 minutes', emoji: '🕐' },
      { value: '20', label: '20 minutes', emoji: '🕑' },
      { value: '30', label: '30 minutes ou plus', emoji: '🕒' },
    ]
  },
  {
    id: 'activite',
    text: 'Qu\'est-ce qui t\'attire le plus ?',
    subtitle: 'Fais-toi confiance, choisis ce qui te parle.',
    type: 'multiple',
    options: [
      { value: 'respirer', label: 'Respirer, me poser, méditer', emoji: '🧘' },
      { value: 'bouger', label: 'Bouger mon corps, être dans la nature', emoji: '🌿' },
      { value: 'creer', label: 'Créer, dessiner, m\'exprimer', emoji: '🎨' },
      { value: 'ecrire', label: 'Écrire, réfléchir, journaler', emoji: '📝' },
      { value: 'visualiser', label: 'Visualiser mes objectifs', emoji: '🎯' },
      { value: 'nature', label: 'Être en lien avec la nature', emoji: '🌳' },
    ]
  },
  {
    id: 'objectif',
    text: 'Quelle est ton intention pour ce parcours ?',
    subtitle: 'Ton intention est ton phare, elle guide ton chemin.',
    type: 'single',
    options: [
      { value: 'apaiser', label: 'Apaiser mon mental', emoji: '🌙' },
      { value: 'grandir', label: 'Grandir et évoluer', emoji: '🌱' },
      { value: 'confiance', label: 'Renforcer ma confiance', emoji: '💎' },
      { value: 'creativite', label: 'Éveiller ma créativité', emoji: '✨' },
      { value: 'presence', label: 'Vivre plus pleinement le présent', emoji: '🌻' },
      { value: 'harmonie', label: 'Trouver l\'harmonie intérieure', emoji: '☯️' },
    ]
  }
]

export const exercises: Exercise[] = [
  // ===== MÉDITATION =====
  {
    id: 'med-1',
    title: 'Respiration consciente',
    category: 'meditation',
    duration: '5-10 min',
    difficulty: 'débutant',
    emoji: '🌬️',
    premium: false, // GRATUIT
    description: 'Une méditation simple centrée sur le souffle pour apaiser ton mental et te reconnecter à l\'instant présent.',
    benefits: ['Réduit le stress', 'Améliore la concentration', 'Calme le système nerveux', 'Clarté mentale'],
    color: 'from-indigo-100 to-purple-100',
    steps: [
      { title: 'Installe-toi confortablement', description: 'Assieds-toi ou allonge-toi dans un endroit calme. Ferme doucement les yeux si tu te sens à l\'aise.', tip: 'Tu peux aussi garder les yeux mi-clos, posés sur un point devant toi.' },
      { title: 'Observe ta respiration', description: 'Sans chercher à la modifier, observe simplement comment tu respires. Sens l\'air qui entre et qui sort.', tip: 'Il n\'y a rien à faire de spécial. Juste observer.' },
      { title: 'Approfondis le souffle', description: 'Inspire lentement par le nez en comptant jusqu\'à 4. Retiens 2 secondes. Expire doucement par la bouche en comptant jusqu\'à 6.', tip: 'L\'expiration plus longue que l\'inspiration active le système de relaxation.' },
      { title: 'Reste avec ton souffle', description: 'Continue ce rythme pendant 5 à 10 minutes. Quand ton esprit s\'égare, ramène-le doucement au souffle, sans te juger.', tip: 'S\'égarer est normal. Revenir est l\'exercice.' },
      { title: 'Reviens en douceur', description: 'Quand tu es prêt·e, ouvre lentement les yeux. Prends un moment pour sentir comment tu te sens.', tip: 'Garde cette sensation de calme avec toi.' }
    ]
  },
  {
    id: 'med-2',
    title: 'Scan corporel bienveillant',
    category: 'meditation',
    duration: '15-20 min',
    difficulty: 'intermédiaire',
    emoji: '🫧',
    premium: true, // PREMIUM
    description: 'Un voyage doux à travers ton corps pour te reconnecter à chaque partie de toi avec bienveillance.',
    benefits: ['Relâche les tensions', 'Favorise le sommeil', 'Augmente la conscience de soi', 'Crée un sentiment de sécurité'],
    color: 'from-blue-100 to-indigo-100',
    steps: [
      { title: 'Allonge-toi', description: 'Allonge-toi confortablement, les bras le long du corps, paumes vers le ciel. Ferme les yeux.', tip: 'Utilise un coussin sous ta tête si besoin.' },
      { title: 'Respire profondément', description: 'Prends 3 grandes respirations. À chaque expiration, laisse ton corps s\'enfoncer davantage dans le support.', tip: 'Imagine que tu fondds dans le sol, en toute sécurité.' },
      { title: 'Commence par les pieds', description: 'Porte ton attention sur tes pieds. Sens les orteils, la plante, les talons. Envoie une vague de douceur dans cette zone.', tip: 'Si tu ne sens rien, c\'est ok aussi.' },
      { title: 'Remonte doucement', description: 'Passe aux jambes, aux hanches, au ventre, à la poitrine... Remonte lentement, avec curiosité et tendresse.', tip: 'Accueille tout ce qui vient, sans vouloir changer quoi que ce soit.' },
      { title: 'Le visage et la tête', description: 'Détends ta mâchoire, ton front, tes yeux. Laisse tout ton visage s\'adoucir.', tip: 'On accumule beaucoup de tensions dans la mâchoire et le front.' },
      { title: 'Enveloppe-toi de douceur', description: 'Imagine une lumière chaude qui enveloppe tout ton corps. Tu es en sécurité. Tu es complet·e.', tip: 'Reste dans cette sensation aussi longtemps que tu le souhaites.' }
    ]
  },
  {
    id: 'med-3',
    title: 'Méditation de gratitude',
    category: 'meditation',
    duration: '10 min',
    difficulty: 'débutant',
    emoji: '🙏',
    premium: false, // GRATUIT
    description: 'Une pratique douce pour cultiver la gratitude et retrouver un sentiment de plénitude.',
    benefits: ['Améliore l\'humeur', 'Renforce la résilience', 'Favorise l\'optimisme', 'Crée du lien avec le positif'],
    color: 'from-yellow-100 to-amber-100',
    steps: [
      { title: 'Installe-toi au calme', description: 'Trouve un endroit paisible. Assieds-toi confortablement et prends quelques respirations profondes.' },
      { title: 'Pense à 3 choses simples', description: 'Identifie 3 choses simples pour lesquelles tu es reconnaissant·e aujourd\'hui. Ça peut être un rayon de soleil, un verre d\'eau, un sourire...', tip: 'Les petites choses comptent autant que les grandes.' },
      { title: 'Ressens la gratitude', description: 'Pour chaque chose, prends un moment pour vraiment ressentir la gratitude dans ton corps. Où la sens-tu ?', tip: 'La gratitude se ressent, pas seulement se pense.' },
      { title: 'Étends la gratitude à toi-même', description: 'Maintenant, envoie de la gratitude envers toi. Tu es là, tu fais ce travail, tu es courageux·se.', tip: 'Tu mérites ta propre tendresse.' },
      { title: 'Clôture avec douceur', description: 'Pose une main sur ton cœur. Dis-toi intérieurement : "Je suis reconnaissant·e pour ce moment." Respire.' }
    ]
  },
  {
    id: 'med-4',
    title: 'Visualisation positive',
    category: 'meditation',
    duration: '10-15 min',
    difficulty: 'débutant',
    emoji: '🌟',
    premium: true, // PREMIUM
    description: 'Visualise ta vie idéale et programme ton mental pour attirer ce que tu désires.',
    benefits: ['Booste la motivation', 'Clarifie tes objectifs', 'Renforce la confiance', 'Programme le succès'],
    color: 'from-violet-100 to-indigo-100',
    steps: [
      { title: 'Détends-toi profondément', description: 'Installe-toi confortablement. Prends 5 grandes respirations pour te détendre complètement.' },
      { title: 'Imagine ton avenir idéal', description: 'Visualise-toi dans 1 an, vivant ta vie idéale. Où es-tu ? Que fais-tu ? Qui t\'entoure ?', tip: 'Sois précis·e dans les détails : couleurs, sons, odeurs...' },
      { title: 'Ressens les émotions', description: 'Comment te sens-tu dans cette vision ? Joie ? Fierté ? Paix ? Amplifie ces émotions.', tip: 'Les émotions sont le carburant de la visualisation.' },
      { title: 'Identifie les premiers pas', description: 'Quelle est la première action concrète que tu pourrais faire dès aujourd\'hui pour te rapprocher de cette vision ?', tip: 'Même un tout petit pas compte.' },
      { title: 'Ancre cette vision', description: 'Prends un moment pour mémoriser cette image. Tu peux y revenir quand tu en as besoin.', tip: 'Note ta vision dans un journal pour la garder vivante.' }
    ]
  },

  // ===== ANCRAGE =====
  {
    id: 'anc-1',
    title: 'L\'arbre intérieur',
    category: 'ancrage',
    duration: '10 min',
    difficulty: 'débutant',
    emoji: '🌳',
    premium: false, // GRATUIT
    description: 'Visualise-toi comme un arbre puissant, enraciné dans la terre, stable et fort malgré les vents.',
    benefits: ['Apporte de la stabilité', 'Renforce la confiance', 'Connecte à la nature', 'Crée un sentiment de solidité'],
    color: 'from-green-100 to-emerald-100',
    steps: [
      { title: 'Debout, pieds ancrés', description: 'Tiens-toi debout, les pieds écartés à largeur de hanches. Sens tes pieds bien ancrés dans le sol.', tip: 'Tu peux aussi le faire assis·e, sens tes pieds sur le sol.' },
      { title: 'Imagine tes racines', description: 'Visualise des racines qui partent de tes pieds et s\'enfoncent profondément dans la terre. Elles sont solides, vivantes.', tip: 'Plus tes racines sont profondes, plus tu es stable.' },
      { title: 'Ton tronc est fort', description: 'Sens ton corps comme un tronc d\'arbre. Solide, droit, vivant. Ta colonne vertébrale est ton tronc.', tip: 'Redresse-toi doucement, avec dignité.' },
      { title: 'Tes branches s\'ouvrent', description: 'Tes bras sont tes branches. Elles s\'ouvrent vers le ciel, accueillant la lumière. Tu es à la fois enraciné·e ET ouvert·e.', tip: 'L\'équilibre entre terre et ciel.' },
      { title: 'Le vent peut souffler', description: 'Imagine que le vent souffle. Tu ondules, mais tu ne tombes pas. Tes racines te tiennent. Tu es solide.', tip: 'Les tempêtes passent, l\'arbre reste.' },
      { title: 'Reviens en douceur', description: 'Prends une grande inspiration. Bouge doucement les doigts et les orteils. Tu ramènes cette force avec toi.' }
    ]
  },
  {
    id: 'anc-2',
    title: 'Les 5 sens',
    category: 'ancrage',
    duration: '5 min',
    difficulty: 'débutant',
    emoji: '👁️',
    premium: false, // GRATUIT
    description: 'Un exercice rapide et puissant pour te reconnecter au moment présent en utilisant tes 5 sens.',
    benefits: ['Stoppe les pensées anxieuses', 'Ramène au présent', 'Simple et rapide', 'Disponible partout'],
    color: 'from-teal-100 to-cyan-100',
    steps: [
      { title: '5 choses que tu VOIS', description: 'Regarde autour de toi. Nomme 5 choses que tu vois. Observe les couleurs, les formes, les détails.', tip: 'Sois précis·e : "Je vois une feuille verte avec des nervures blanches."' },
      { title: '4 choses que tu TOUCHES', description: 'Sens 4 choses que tu peux toucher. Le tissu de tes vêtements, le sol sous tes pieds, l\'air sur ta peau...', tip: 'Concentre-toi sur les sensations physiques.' },
      { title: '3 choses que tu ENTENDS', description: 'Écoute. Identifie 3 sons. Ils peuvent être lointains ou proches. Le silence est aussi un son.', tip: 'Même dans le calme, il y a toujours quelque chose à entendre.' },
      { title: '2 choses que tu SENS', description: 'Identifie 2 odeurs autour de toi. L\'air, un parfum, une odeur de cuisine...', tip: 'Si tu ne sens rien, approche ton nez de ta peau.' },
      { title: '1 chose que tu GOÛTES', description: 'Concentre-toi sur le goût dans ta bouche. Même si c\'est juste le goût du vide ou de ta salive.', tip: 'Tu peux aussi boire une gorgée d\'eau pour activer ce sens.' }
    ]
  },
  {
    id: 'anc-3',
    title: 'La marche consciente',
    category: 'ancrage',
    duration: '15-20 min',
    difficulty: 'intermédiaire',
    emoji: '🚶',
    premium: true, // PREMIUM
    description: 'Marche en pleine conscience pour te reconnecter à ton corps et à la nature qui t\'entoure.',
    benefits: ['Relie le corps et l\'esprit', 'Réduit le stress', 'Énergise en douceur', 'Accessible à tous'],
    color: 'from-lime-100 to-green-100',
    steps: [
      { title: 'Choisis ton chemin', description: 'Trouve un chemin calme, même court (10 mètres suffisent). Tu feras des allers-retours.', tip: 'La nature est idéale, mais un couloir fonctionne aussi.' },
      { title: 'Commence lentement', description: 'Marche beaucoup plus lentement que d\'habitude. Sens chaque pas : le talon qui se pose, le pied qui roule, les orteils qui poussent.', tip: 'La lenteur est l\'exercice.' },
      { title: 'Synchronise avec le souffle', description: 'Inspire en 2 pas, expire en 3 pas. Trouve ton propre rythme.', tip: 'Le souffle et le mouvement ensemble créent une méditation en mouvement.' },
      { title: 'Sois présent·e à chaque pas', description: 'Quand ton esprit s\'égare, reviens à la sensation des pieds sur le sol. Chaque pas est un retour au présent.', tip: 'Chaque pas est un miracle : tu es vivant·e, tu marches.' },
      { title: 'Termine en conscience', description: 'Avant de reprendre ta marche normale, arrête-toi. Ferme les yeux. Sens ton corps entier, vibrant de vie.' }
    ]
  },
  {
    id: 'anc-4',
    title: 'Bain de nature',
    category: 'ancrage',
    duration: '20-30 min',
    difficulty: 'débutant',
    emoji: '🌲',
    premium: true, // PREMIUM
    description: 'Immerge-toi dans la nature en pleine conscience pour te reconnecter à l\'essentiel et recharger tes batteries.',
    benefits: ['Recharge énergétiquement', 'Réduit le stress', 'Inspire la créativité', 'Renforce le bien-être'],
    color: 'from-emerald-100 to-teal-100',
    steps: [
      { title: 'Choisis ton lieu', description: 'Trouve un espace naturel : parc, forêt, jardin, bord de mer... Même un petit espace vert suffit.', tip: 'Laisse ton téléphone de côté pour cette expérience.' },
      { title: 'Arrête-toi et respire', description: 'Une fois sur place, prends 5 grandes respirations profondes. Imprègne-toi de l\'air, des odeurs naturelles.', tip: 'L\'air en nature est souvent plus pur et oxygéné.' },
      { title: 'Observe avec curiosité', description: 'Regarde autour de toi comme si tu voyais tout pour la première fois. Les couleurs, les textures, les mouvements.', tip: 'Cherche les petits détails : une feuille, un insecte, un jeu de lumière...' },
      { title: 'Écoute les sons', description: 'Ferme les yeux et écoute. Le vent dans les arbres, les oiseaux, le silence... Chaque son est unique.', tip: 'La nature a sa propre musique.' },
      { title: 'Touche la nature', description: 'Touche l\'écorce d\'un arbre, caresse une feuille, sens la terre sous tes pieds. Connecte-toi physiquement.', tip: 'Le contact avec la nature est profondément apaisant.' },
      { title: 'Remercie', description: 'Avant de partir, prends un moment pour remercier la nature pour ce moment de paix.', tip: 'Tu peux revenir ici quand tu en as besoin.' }
    ]
  },

  // ===== CRÉATIVITÉ & EXPRESSION =====
  {
    id: 'art-1',
    title: 'Le dessin intuitif',
    category: 'art-therapie',
    duration: '15-20 min',
    difficulty: 'débutant',
    emoji: '🎨',
    premium: false, // GRATUIT
    description: 'Exprime-toi à travers les couleurs et les formes, sans chercher à faire "beau". Juste à exprimer.',
    benefits: ['Libère la créativité', 'Développe la conscience de soi', 'Réduit le stress', 'Nécessite aucun talent artistique'],
    color: 'from-pink-100 to-rose-100',
    steps: [
      { title: 'Prépare ton espace', description: 'Installe-toi avec du papier et des crayons de couleur, feutres ou peinture. Peu importe le matériel.', tip: 'Pas besoin de matériel cher. Un stylo et une feuille suffisent.' },
      { title: 'Connecte-toi à ton état', description: 'Ferme les yeux un instant. Comment te sens-tu ? Quelle énergie est présente en toi ? Ne juge pas, observe.', tip: 'Si tu ne sais pas, c\'est ok. Laisse venir.' },
      { title: 'Laisse-toi guider', description: 'Pose ton crayon sur le papier et laisse ta main bouger. Ne réfléchis pas trop. Fais confiance à ton intuition.', tip: 'Il n\'y a pas de bon ou mauvais dessin.' },
      { title: 'Explore les couleurs', description: 'Choisis les couleurs qui t\'attirent. Ajoute des formes, des lignes, des motifs. Laisse-toi surprendre.', tip: 'La logique viendra après. Pour l\'instant, juste crée.' },
      { title: 'Contemple ton œuvre', description: 'Quand tu as fini, regarde ton dessin. Que te dit-il ? Que ressens-tu en le voyant ?', tip: 'Ton inconscient s\'est exprimé. Écoute-le avec curiosité.' },
      { title: 'Accueille sans juger', description: 'Ce dessin est l\'expression de toi, ici et maintenant. Il est parfait tel qu\'il est.', tip: 'Tu peux le garder, le déchirer, ou le garder précieusement.' }
    ]
  },
  {
    id: 'art-2',
    title: 'Le mandala personnel',
    category: 'art-therapie',
    duration: '20-30 min',
    difficulty: 'intermédiaire',
    emoji: '🔮',
    premium: true, // PREMIUM
    description: 'Crée ton propre mandala, un cercle sacré qui représente ton monde intérieur et t\'apporte de la centrabilité.',
    benefits: ['Centre et recentre', 'Favorise la méditation', 'Harmonise les émotions', 'Crée un sentiment de complétude'],
    color: 'from-fuchsia-100 to-pink-100',
    steps: [
      { title: 'Trace ton cercle', description: 'Dessine un grand cercle au centre de ta feuille. C\'est ton espace sacré, ton univers.', tip: 'Utilise un compas ou un objet rond. Ou fais-le librement.' },
      { title: 'Commence par le centre', description: 'Au centre du cercle, dessine quelque chose qui te représente. Un symbole, une forme, une couleur.', tip: 'Le centre, c\'est toi, ton essence.' },
      { title: 'Crée des couches', description: 'Autour du centre, ajoute des formes concentriques. Laisse-toi guider. Répète des motifs si ça te parle.', tip: 'La répétition est apaisante et méditative.' },
      { title: 'Choisis tes couleurs', description: 'Utilise les couleurs qui te parlent. Il n\'y a pas de règles. Les couleurs expriment ce que les mots ne peuvent pas dire.', tip: 'Fais confiance à ton instinct.' },
      { title: 'Contemple ton mandala', description: 'Quand tu as terminé, regarde ton mandala dans son ensemble. C\'est une représentation de ton monde intérieur, en ce moment.' }
    ]
  },
  {
    id: 'art-3',
    title: 'L\'écriture intuitive',
    category: 'art-therapie',
    duration: '10-15 min',
    difficulty: 'débutant',
    emoji: '✍️',
    premium: false, // GRATUIT
    description: 'Écris sans filtre, sans censure, tout ce qui te vient. Un espace de liberté totale pour ton esprit.',
    benefits: ['Libère les pensées', 'Clarifie l\'esprit', 'Réduit le stress', 'Favorise la connaissance de soi'],
    color: 'from-violet-100 to-purple-100',
    steps: [
      { title: 'Prépare-toi', description: 'Prends un carnet et un stylo. Trouve un endroit calme. Mets un minuteur sur 10 minutes.', tip: 'L\'écriture à la main est plus libératrice que le clavier.' },
      { title: 'Commence à écrire', description: 'Écris tout ce qui te passe par la tête. Sans t\'arrêter. Sans corriger. Sans juger. Même si c\'est "je ne sais pas quoi écrire".', tip: 'Le but n\'est pas d\'écrire bien. Le but est d\'écrire.' },
      { title: 'Laisse venir', description: 'Si des idées, des souvenirs, des envies montent, écris-les. "Je pense à...", "J\'aimerais...", "Je rêve de..."', tip: 'C\'est ton espace. Tout est permis.' },
      { title: 'Ne te relis pas (tout de suite)', description: 'Continue d\'écrire jusqu\'à la fin du temps. Ne te relis pas. Ce texte est pour toi, pas pour les autres.', tip: 'La relecture viendra plus tard, si tu le souhaites.' },
      { title: 'Accueille ce qui est sorti', description: 'Relis doucement. Qu\'as-tu découvert ? Y a-t-il des messages importants ? Note-les.', tip: 'Ton inconscient parle à travers tes mots.' }
    ]
  },
  {
    id: 'art-4',
    title: 'Le tableau de vision',
    category: 'art-therapie',
    duration: '30-45 min',
    difficulty: 'débutant',
    emoji: '🖼️',
    premium: true, // PREMIUM
    description: 'Crée un collage visuel de tes rêves et objectifs pour les matérialiser et les garder vivants.',
    benefits: ['Clarifie tes objectifs', 'Booste la motivation', 'Matérialise tes rêves', 'Inspire l\'action'],
    color: 'from-rose-100 to-pink-100',
    steps: [
      { title: 'Rassemble ton matériel', description: 'Magazines, ciseaux, colle, et un grand carton. Ou utilise des images imprimées d\'internet.', tip: 'Tu peux aussi le faire en numérique avec Canva ou Pinterest.' },
      { title: 'Définis tes domaines de vie', description: 'Pense aux différents aspects : carrière, relations, santé, créativité, voyages, spiritualité...', tip: 'Choisis 3-5 domaines qui comptent le plus pour toi.' },
      { title: 'Choisis tes images', description: 'Parcours tes magazines et choisis des images, mots, couleurs qui représentent ce que tu veux dans ta vie.', tip: 'Fais confiance à ton instinct. Ce qui t\'attire est important.' },
      { title: 'Compose ton tableau', description: 'Dispose et colle tes images sur le carton. Crée des associations, des compositions qui te parlent.', tip: 'Il n\'y a pas de règles esthétiques. C\'est ton vision.' },
      { title: 'Place-le en vue', description: 'Accroche ton tableau de vision là où tu le verras chaque jour. Il sera ton rappel constant de tes aspirations.', tip: 'Regarde-le chaque matin pour te reconnecter à tes rêves.' }
    ]
  },

  // ===== CONNAISSANCE DE SOI =====
  {
    id: 'emo-1',
    title: 'Le journal de gratitude',
    category: 'emotionnel',
    duration: '5-10 min',
    difficulty: 'débutant',
    emoji: '📔',
    premium: false, // GRATUIT
    description: 'Chaque jour, note 3 choses pour lesquelles tu es reconnaissant·e. Un exercice simple mais profondément transformateur.',
    benefits: ['Recentre sur le positif', 'Améliore l\'humeur', 'Renforce la résilience', 'Change la perspective'],
    color: 'from-orange-100 to-amber-100',
    steps: [
      { title: 'Choisis un moment', description: 'Le matin au réveil ou le soir avant de dormir. Un moment calme, rien que pour toi.', tip: 'La régularité est plus importante que la durée.' },
      { title: 'Écris 3 gratitudes', description: 'Note 3 choses pour lesquelles tu es reconnaissant·e aujourd\'hui. Elles peuvent être toutes simples.', tip: 'Exemples : un café chaud, un message d\'un·e ami·e, le chant des oiseaux...' },
      { title: 'Développe chaque gratitude', description: 'Pour chaque chose, écris pourquoi tu es reconnaissant·e. Comment ça te fait te sentir ?', tip: 'Plus tu détails, plus l\'effet est puissant.' },
      { title: 'Inclus-toi', description: 'Ajoute une gratitude envers toi-même. Qu\'as-tu fait aujourd\'hui qui mérite reconnaissance ?', tip: 'Même "je me suis levé·e" est une gratitude valable.' },
      { title: 'Ressens la gratitude', description: 'Relis tes gratitudes et laisse monter le sentiment. Souris si tu peux. C\'est ça, la magie.', tip: 'La gratitude se ressent dans le corps.' }
    ]
  },
  {
    id: 'emo-2',
    title: 'La lettre à soi-même',
    category: 'emotionnel',
    duration: '15-20 min',
    difficulty: 'intermédiaire',
    emoji: '💌',
    premium: true, // PREMIUM
    description: 'Écris une lettre tendre et bienveillante à toi-même, comme tu l\'écrirais à un·e ami·e cher·e.',
    benefits: ['Développe la compassion envers soi', 'Apaise le stress', 'Renforce l\'estime de soi', 'Crée un lien intérieur'],
    color: 'from-rose-100 to-pink-100',
    steps: [
      { title: 'Installe-toi', description: 'Trouve un endroit calme. Prends quelques respirations profondes. Pense à toi, à la partie de toi qui a besoin de tendresse.' },
      { title: 'Commence ta lettre', description: 'Écris "Cher/Chère moi," ou "À moi-même,". Écris comme tu parlerais à ton meilleur·e ami·e.', tip: 'Utilise "tu" ou "je", comme tu préfères.' },
      { title: 'Reconnais ton parcours', description: 'Écris ce que tu as accompli, les défis que tu as surmontés. Célèbre tes victoires, même petites.', tip: 'On oublie souvent tout ce qu\'on a déjà traversé.' },
      { title: 'Offre de la compassion', description: 'Écris des mots de tendresse. "Tu fais de ton mieux. Tu es courageux·se. Tu mérites du bonheur."', tip: 'Si c\'est difficile, imagine ce que tu dirais à un·e enfant ou un·e ami·e.' },
      { title: 'Rappelle ta force', description: 'Écris ce que tu admires chez toi. Tes qualités, tes forces, les moments où tu as été fort·e.', tip: 'On oublie souvent nos propres forces.' },
      { title: 'Termine avec amour', description: 'Termine ta lettre par des mots d\'amour. "Je suis là pour toi. Je crois en toi. Je t\'aime."', tip: 'Relis cette lettre quand tu en as besoin.' }
    ]
  },
  {
    id: 'emo-3',
    title: 'Les valeurs personnelles',
    category: 'emotionnel',
    duration: '20-30 min',
    difficulty: 'intermédiaire',
    emoji: '💎',
    premium: true, // PREMIUM
    description: 'Découvre tes valeurs fondamentales pour aligner ta vie avec ce qui compte vraiment pour toi.',
    benefits: ['Clarifie tes choix', 'Donne du sens', 'Guide tes décisions', 'Renforce l\'authenticité'],
    color: 'from-amber-100 to-yellow-100',
    steps: [
      { title: 'Liste tes moments de fierté', description: 'Écris 5 moments de ta vie où tu t\'es senti·e vraiment fier·e de toi. Qu\'est-ce qui rendait ces moments spéciaux ?', tip: 'Ces moments révèlent tes valeurs en action.' },
      { title: 'Identifie les thèmes', description: 'Relis tes moments. Quels thèmes reviennent ? Créativité ? Liberté ? Famille ? Aventure ? Service ?', tip: 'Note tous les mots qui te viennent.' },
      { title: 'Choisis tes 5 valeurs', description: 'Parmi tous ces thèmes, choisis les 5 qui résonnent le plus profondément en toi.', tip: 'Tes valeurs sont ta boussole intérieure.' },
      { title: 'Définis chaque valeur', description: 'Pour chaque valeur, écris ce qu\'elle signifie pour toi concrètement. Comment elle se manifeste dans ta vie ?', tip: 'Les valeurs sont personnelles. Ta définition est la bonne.' },
      { title: 'Évalue ton alignement', description: 'Sur une échelle de 1 à 10, à quel point ta vie actuelle reflète chacune de tes valeurs ?', tip: 'Les écarts sont des pistes d\'évolution.' },
      { title: 'Planifie des actions', description: 'Pour chaque valeur, identifie une petite action concrète que tu peux faire cette semaine pour t\'y aligner davantage.', tip: 'Même un petit pas compte.' }
    ]
  },
  {
    id: 'emo-4',
    title: 'Les affirmations positives',
    category: 'emotionnel',
    duration: '5-10 min',
    difficulty: 'débutant',
    emoji: '✨',
    premium: false, // GRATUIT
    description: 'Crée et répète des affirmations positives pour reprogrammer ton mental et renforcer ta confiance.',
    benefits: ['Renforce la confiance', 'Change le dialogue intérieur', 'Attire le positif', 'Booste l\'estime de soi'],
    color: 'from-yellow-100 to-orange-100',
    steps: [
      { title: 'Observe ton dialogue intérieur', description: 'Pendant une journée, note les pensées négatives automatiques. "Je n\'y arriverai pas", "Je ne suis pas assez..."', tip: 'Prendre conscience est la première étape.' },
      { title: 'Transforme en positif', description: 'Pour chaque pensée négative, crée une affirmation positive opposée. "Je suis capable", "Je suis suffisant·e".', tip: 'Utilise le présent : "Je suis" et non "Je serai".' },
      { title: 'Choisis tes 5 affirmations', description: 'Sélectionne 5 affirmations qui résonnent le plus avec tes objectifs et tes besoins actuels.', tip: 'Elles doivent te sembler vraies, ou du moins possibles.' },
      { title: 'Répète chaque jour', description: 'Chaque matin, répète tes affirmations à voix haute, devant le miroir si possible. Avec conviction.', tip: 'La répétition est la clé. Fais-en un rituel.' },
      { title: 'Ressens-les', description: 'Ne te contente pas de les dire. Ressens-les dans ton corps. Laisse-les pénétrer en toi.', tip: 'Les émotions amplifient l\'effet des affirmations.' }
    ]
  }
]

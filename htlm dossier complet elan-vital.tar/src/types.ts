export interface Answer {
  questionId: string
  value: string | number | string[]
}

export interface Question {
  id: string
  text: string
  subtitle?: string
  type: 'single' | 'multiple' | 'scale'
  options?: { value: string; label: string; emoji: string }[]
  scaleMin?: number
  scaleMax?: number
  scaleLabels?: { min: string; max: string }
}

export interface Exercise {
  id: string
  title: string
  category: 'meditation' | 'ancrage' | 'art-therapie' | 'emotionnel'
  duration: string
  difficulty: 'débutant' | 'intermédiaire' | 'avancé'
  description: string
  emoji: string
  benefits: string[]
  steps: { title: string; description: string; tip?: string }[]
  color: string
  premium: boolean
}

export type Category = 'meditation' | 'ancrage' | 'art-therapie' | 'emotionnel'

export interface CategoryInfo {
  id: Category
  title: string
  emoji: string
  description: string
  color: string
  bgColor: string
}
